# SimVLA Online Risk Controller — Complementary Reproduction Bundle

This bundle complements the earlier risk-head architecture/data package. It focuses on the missing **online execution layer**: how nine SimVLA actions are sampled, how deterministic seeds are derived, how each candidate is scored by the same temporal risk monitor, how the two thresholds choose the final candidate, and how the selected H10 chunk is executed in Isaac.

## Deliberately omitted
- SimVLA checkpoint weights (`model.safetensors`)
- risk-head checkpoint weights (`model.pt`)
- SmolVLM base weights/assets
- large rollout datasets/videos

Small normalization/configuration metadata is included because it defines exact interfaces.

## Start here
1. `00_DOCS/FILE_GUIDE.md`
2. `00_DOCS/SYSTEM_OVERVIEW.md`
3. `00_DOCS/RANDOMNESS_AND_REPRODUCIBILITY_MAP.md`
4. `00_DOCS/SEED_AND_CANDIDATE_GENERATION.md`
5. `00_DOCS/TWO_THRESHOLD_SELECTION.md`
6. `00_DOCS/ACTION_EXECUTION_AND_HISTORY.md`
7. `00_DOCS/PORTING_TO_MIMIC_VIDEO.md`
8. `06_MINIMAL_REFERENCE/seed_and_selector_reference.py`

The canonical OOD400 scene manifest is included so another policy can be evaluated on the exact same 400 scenes.

The `03_SIMVLA_ACTION_GENERATION/simvla_models/` and `isaac_runtime/` directories include the exact Python implementation of the action generator/runtime used by this evaluation, but no checkpoint or base-model weights.