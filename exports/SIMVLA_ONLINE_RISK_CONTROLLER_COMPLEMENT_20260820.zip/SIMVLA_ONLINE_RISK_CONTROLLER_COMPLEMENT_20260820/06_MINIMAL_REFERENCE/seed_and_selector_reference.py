#!/usr/bin/env python3
"""Minimal dependency-light reference for SimVLA TopK seed derivation and two-threshold selection."""
import hashlib
import numpy as np
TOTAL_CANDIDATES = 9

def deterministic_candidate_seed(global_seed:int, source_episode_id:int, decision_index:int, candidate_index:int)->int:
    key=f"simvla-isaac-risk-v1|{global_seed}|{source_episode_id}|{decision_index}|{candidate_index}".encode("ascii")
    return int(hashlib.sha256(key).hexdigest()[:16],16) % (2**31-1)

def candidate_seeds(global_seed:int, source_episode_id:int, decision_index:int):
    return tuple(deterministic_candidate_seed(global_seed,source_episode_id,decision_index,i) for i in range(TOTAL_CANDIDATES))

def select(scores, A, C, M=0.0):
    s=np.asarray(scores,dtype=float)
    assert s.shape==(9,) and np.isfinite(s).all()
    main=float(s[0]); best_idx=int(np.argmin(s[1:]))+1; best=float(s[best_idx]); delta=main-best
    if best >= main: return 0,"main_is_lowest"
    if main < A: return 0,"main_below_alarm_threshold"
    if best > C: return 0,"best_alternative_above_cap"
    if delta < M: return 0,"risk_delta_below_min_delta"
    return best_idx,"argmin_on_alarm_cap_pass"

if __name__=='__main__':
    print('example seeds:', candidate_seeds(20260812,0,0))
    print(select([0.95,0.94,0.92,0.20,0.91,0.89,0.88,0.87,0.86], A=0.8792325258255005, C=0.90))
