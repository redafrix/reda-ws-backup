from __future__ import annotations
from typing import Iterable, Tuple, Dict, Type, Optional
from pathlib import Path
import json
import torch
import torch.nn as nn
import numpy as np


# =============================================================================
# Normalization Stats
# =============================================================================
class NormStats:
    """Normalization statistics for action normalization."""
    
    def __init__(
        self,
        mean: np.ndarray,
        std: np.ndarray,
        q01: Optional[np.ndarray] = None,
        q99: Optional[np.ndarray] = None,
    ):
        self.mean = torch.as_tensor(mean, dtype=torch.float32)
        self.std = torch.as_tensor(std, dtype=torch.float32)
        self.q01 = torch.as_tensor(q01, dtype=torch.float32) if q01 is not None else None
        self.q99 = torch.as_tensor(q99, dtype=torch.float32) if q99 is not None else None
        
    def to(self, device):
        """Move to specified device."""
        self.mean = self.mean.to(device)
        self.std = self.std.to(device)
        if self.q01 is not None:
            self.q01 = self.q01.to(device)
        if self.q99 is not None:
            self.q99 = self.q99.to(device)
        return self


def load_norm_stats(path: str) -> Dict[str, NormStats]:
    """
    Load normalization statistics from JSON file.
    
    Supports two formats:
    1. Legacy format (action stats only):
       {"action": {"mean": [...], "std": [...], ...}}
       
    2. Extended format (separate state and actions stats):
       {"norm_stats": {"state": {...}, "actions": {...}}}
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Norm stats file not found: {path}")
        
    with open(path) as f:
        data = json.load(f)
    
    result = {}
    
    # Check if it's extended format (has norm_stats key)
    if "norm_stats" in data:
        data = data["norm_stats"]
    
    for key, stats in data.items():
        if key == "metadata":
            continue
        result[key] = NormStats(
            mean=np.array(stats["mean"], dtype=np.float32),
            std=np.array(stats["std"], dtype=np.float32),
            q01=np.array(stats.get("q01"), dtype=np.float32) if stats.get("q01") else None,
            q99=np.array(stats.get("q99"), dtype=np.float32) if stats.get("q99") else None,
        )
    return result


# =============================================================================
# Registry
# =============================================================================
ACTION_REGISTRY: Dict[str, Type["BaseActionSpace"]] = {}


def register_action(name: str):
    """Decorator for registering a new action space."""
    def _wrap(cls):
        key = name.lower()
        if key in ACTION_REGISTRY:
            raise KeyError(f"ActionSpace '{key}' already registered -> {ACTION_REGISTRY[key]}")
        ACTION_REGISTRY[key] = cls
        cls.name = key
        return cls
    return _wrap


def build_action_space(name: str, **kwargs) -> "BaseActionSpace":
    """Instantiate a registered action space by name."""
    key = name.lower()
    if key not in ACTION_REGISTRY:
        raise KeyError(f"Unknown action space '{name}'. Available: {list(ACTION_REGISTRY.keys())}")
    return ACTION_REGISTRY[key](**kwargs)


# =============================================================================
# Base class
# =============================================================================
class BaseActionSpace(nn.Module):
    """
    Abstract base class for all action-space definitions.

    Each subclass defines:
      - `dim_action`: dimension of the action vector.
      - `gripper_idx`: indices of gripper channels.
      - `compute_loss(pred, target)`: supervised loss for this space.
      - `preprocess(proprio, action, mode)`: pre-step modifications.
      - `postprocess(action)`: post-step corrections.
    """

    name: str = "base"
    dim_action: int = 0
    gripper_idx: Tuple[int, ...] = ()

    def __init__(self):
        super().__init__()

    def compute_loss(self, pred: torch.Tensor, target: torch.Tensor) -> Dict[str, torch.Tensor]:
        raise NotImplementedError

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Alias for compute_loss."""
        return self.compute_loss(pred, target)

    def preprocess(
        self,
        proprio: torch.Tensor,
        action: torch.Tensor,
        mode: str = "train",
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Default: return unchanged."""
        return proprio, action

    def postprocess(self, action: torch.Tensor) -> torch.Tensor:
        """Default: return unchanged."""
        return action


# =============================================================================
# Utilities
# =============================================================================
def _ensure_indices_valid(D: int, idx: Iterable[int], name: str) -> None:
    bad = [i for i in idx if i < 0 or i >= D]
    if bad:
        raise IndexError(f"{name} contains out-of-range indices {bad} for action dim D={D}")


# =============================================================================
# LIBERO Action Space
# =============================================================================
@register_action("libero_joint")
class LiberoJointActionSpace(BaseActionSpace):
    """
    LIBERO joint/delta action space.
    
    Data layout:
      - state (proprio): 8-dim [ee_pos(3), ee_ori(3), gripper_states(2)]
      - actions: 7-dim [delta_xyz(3), delta_euler(3), gripper_cmd(1)]
      
    Actions range: [-1, 1] (normalized delta actions)
    
    - Uses MSE loss
    - Optional Z-score or Quantile normalization
    """

    dim_action = 7
    dim_proprio = 8
    gripper_idx = (6,)  # Last dimension is gripper

    def __init__(
        self,
        norm_stats_path: Optional[str] = None,
        use_quantile_norm: bool = False,
    ):
        super().__init__()
        self.use_quantile_norm = use_quantile_norm
        self.state_norm_stats: Optional[NormStats] = None
        self.action_norm_stats: Optional[NormStats] = None
        
        if norm_stats_path:
            self.load_norm_stats(norm_stats_path)
            
    def load_norm_stats(self, path: str):
        """Load normalization statistics."""
        stats_dict = load_norm_stats(path)
        
        if "state" in stats_dict:
            self.state_norm_stats = stats_dict["state"]
            print(f"[LiberoJointActionSpace] Loaded state norm stats, dim={len(self.state_norm_stats.mean)}")
            
        if "actions" in stats_dict:
            self.action_norm_stats = stats_dict["actions"]
            print(f"[LiberoJointActionSpace] Loaded actions norm stats, dim={len(self.action_norm_stats.mean)}")
            
    def to(self, device):
        """Move to specified device."""
        if self.state_norm_stats is not None:
            self.state_norm_stats.to(device)
        if self.action_norm_stats is not None:
            self.action_norm_stats.to(device)
        return super().to(device)
    
    def _normalize_with_stats(self, x: torch.Tensor, stats: NormStats) -> torch.Tensor:
        """Normalize using specified statistics."""
        if stats.mean.device != x.device:
            stats.to(x.device)
        
        D = x.shape[-1]
        
        if self.use_quantile_norm and stats.q01 is not None and stats.q99 is not None:
            q01 = stats.q01[..., :D]
            q99 = stats.q99[..., :D]
            return (x - q01) / (q99 - q01 + 1e-6) * 2.0 - 1.0
        else:
            mean = stats.mean[..., :D]
            std = stats.std[..., :D]
            return (x - mean) / (std + 1e-6)
    
    def _unnormalize_with_stats(self, x: torch.Tensor, stats: NormStats) -> torch.Tensor:
        """Unnormalize using specified statistics."""
        if stats.mean.device != x.device:
            stats.to(x.device)
        
        D = x.shape[-1]
            
        if self.use_quantile_norm and stats.q01 is not None and stats.q99 is not None:
            q01 = stats.q01[..., :D]
            q99 = stats.q99[..., :D]
            return (x + 1.0) / 2.0 * (q99 - q01 + 1e-6) + q01
        else:
            mean = stats.mean[..., :D]
            std = stats.std[..., :D]
            return x * (std + 1e-6) + mean
    
    def normalize_state(self, x: torch.Tensor) -> torch.Tensor:
        """Normalize state/proprio."""
        if self.state_norm_stats is not None:
            return self._normalize_with_stats(x, self.state_norm_stats)
        return x
    
    def normalize_action(self, x: torch.Tensor) -> torch.Tensor:
        """Normalize action."""
        if self.action_norm_stats is not None:
            return self._normalize_with_stats(x, self.action_norm_stats)
        return x
    
    def unnormalize_action(self, x: torch.Tensor) -> torch.Tensor:
        """Unnormalize action."""
        if self.action_norm_stats is not None:
            return self._unnormalize_with_stats(x, self.action_norm_stats)
        return x

    def compute_loss(self, pred, target):
        """Full-dimension MSE loss."""
        loss = torch.square(pred - target)
        return {"velocity_loss": torch.mean(loss)}

    def preprocess(self, proprio, action, mode="train"):
        """Normalize proprio and action separately."""
        proprio_norm = self.normalize_state(proprio)
        action_norm = self.normalize_action(action)
        return proprio_norm, action_norm

    def postprocess(self, action: torch.Tensor) -> torch.Tensor:
        """Unnormalize action."""
        return self.unnormalize_action(action)


@register_action("isaaclab_absolute_macro")
class IsaacLabAbsoluteMacroActionSpace(LiberoJointActionSpace):
    """
    IsaacLab absolute 20 Hz macro action space.

    Layout:
      - state: [ee_pos_env_local(3), ee_axis_angle(3), gripper(2)]
      - action: [next_ee_pos_env_local(3), next_ee_euler_xyz(3), gripper_cmd(1)]

    The normalization/loss path is identical to LiberoJointActionSpace; the
    separate registry name prevents silent use of relative-delta decoding.
    """


@register_action("isaaclab_delta_ee")
class IsaacLabDeltaEEActionSpace(LiberoJointActionSpace):
    """
    IsaacLab 30 Hz per-tick end-effector delta action space.

    Layout:
      - state: [ee_pos_env_local(3), ee_axis_angle(3), gripper(2)]
      - action: [target_pos_w - live_ee_pos_w(3), rotvec(target_ee * live_ee^-1)(3), gripper_cmd(1)]

    The normalization/loss path is identical to LiberoJointActionSpace; the
    separate registry name prevents silent use of LIBERO-scaled delta decoding.
    """

    EXPECTED_CONVERSION_VERSION = "isaaclab_hdf5_world_left_delta_fixed_initial_reaching_orientation_v3"
    EXPECTED_ROTATION_TARGET = "reaching_episode_initial_ee_quat_wxyz_absolute_else_raw_controller_target"
    EXPECTED_ACTION_STATS_SOURCE = "handler_raw_rows_t_to_t_plus_horizon_minus_1_last_row_padded"

    def load_norm_stats(self, path: str):
        super().load_norm_stats(path)
        if self.state_norm_stats is None or self.action_norm_stats is None:
            raise ValueError(
                f"IsaacLab delta-EE norm stats must contain both state and actions entries: {path}"
            )
        self._require_stats_array("state", self.state_norm_stats, self.dim_proprio)
        self._require_stats_array("actions", self.action_norm_stats, self.dim_action)

        with Path(path).open(encoding="utf-8") as handle:
            payload = json.load(handle)
        metadata = payload.get("metadata", {})
        checks = {
            "dataset_family": "isaaclab",
            "conversion_convention_version": self.EXPECTED_CONVERSION_VERSION,
            "action_rotation_target_convention": self.EXPECTED_ROTATION_TARGET,
            "action_stats_source": self.EXPECTED_ACTION_STATS_SOURCE,
            "num_actions": 10,
            "state_dim": self.dim_proprio,
            "action_dim": self.dim_action,
        }
        for key, expected in checks.items():
            actual = metadata.get(key)
            if actual != expected:
                raise ValueError(
                    f"IsaacLab norm stats metadata {key}={actual!r}, expected {expected!r}: {path}"
                )

    @staticmethod
    def _require_stats_array(name: str, stats: NormStats, expected_dim: int) -> None:
        arrays = {"mean": stats.mean, "std": stats.std}
        if stats.q01 is not None:
            arrays["q01"] = stats.q01
        if stats.q99 is not None:
            arrays["q99"] = stats.q99
        for field, values in arrays.items():
            if tuple(values.shape) != (expected_dim,):
                raise ValueError(
                    f"IsaacLab {name} norm {field} must have shape {(expected_dim,)}, "
                    f"got {tuple(values.shape)}"
                )
            if not torch.isfinite(values).all():
                raise ValueError(f"IsaacLab {name} norm {field} contains non-finite values")
        if torch.any(stats.std < 0):
            raise ValueError(f"IsaacLab {name} norm std contains negative values")


@register_action("isaaclab_base_delta_ee")
class IsaacLabBaseDeltaEEActionSpace(IsaacLabDeltaEEActionSpace):
    """Strict robot-base command-increment action space."""

    EXPECTED_CONVERSION_VERSION = (
        "isaaclab_hdf5_robot_base_command_increment_legacy_tcp_salvage_reaching_v6"
    )
    EXPECTED_ROTATION_TARGET = "measured_ee_orientation_trajectory"
    EXPECTED_ACTION_LABEL_MODE = (
        "base_command_increment_measured_orientation_binary_gripper_30hz"
    )
    EXPECTED_COORDINATE_FRAME = "robot_base"
    EXPECTED_ACTION_TRANSLATION = (
        "robot_base_command_target_next_minus_current_after_legacy_tcp_salvage_m"
    )
    EXPECTED_ACTION_ROTATION = (
        "robot_base_measured_ee_next_times_current_inv_rotvec_rad"
    )
    EXPECTED_ACTION_TEMPORAL_ALIGNMENT = (
        "handler_returns_actions_t_to_t_plus_horizon_minus_1_last_row_padded"
    )
    EXPECTED_ORIENTATION_SOURCE = (
        "measured_ee_consecutive_left_rotvec"
    )

    def load_norm_stats(self, path: str):
        LiberoJointActionSpace.load_norm_stats(self, path)
        if self.state_norm_stats is None or self.action_norm_stats is None:
            raise ValueError(
                f"IsaacLab v4 norm stats require state and actions entries: {path}"
            )
        self._require_stats_array("state", self.state_norm_stats, self.dim_proprio)
        self._require_stats_array("actions", self.action_norm_stats, self.dim_action)

        with Path(path).open(encoding="utf-8") as handle:
            metadata = json.load(handle).get("metadata")
        if not isinstance(metadata, dict):
            raise ValueError(f"IsaacLab v6 norm stats are missing metadata: {path}")
        checks = {
            "dataset_family": "isaaclab",
            "conversion_convention_version": self.EXPECTED_CONVERSION_VERSION,
            "action_mode": "isaaclab_base_delta_ee",
            "action_rotation_target_convention": self.EXPECTED_ROTATION_TARGET,
            "action_translation_convention": self.EXPECTED_ACTION_TRANSLATION,
            "action_rotation_convention": self.EXPECTED_ACTION_ROTATION,
            "action_temporal_alignment": self.EXPECTED_ACTION_TEMPORAL_ALIGNMENT,
            "action_stats_source": self.EXPECTED_ACTION_STATS_SOURCE,
            "coordinate_frame": self.EXPECTED_COORDINATE_FRAME,
            "orientation_supervision_source": self.EXPECTED_ORIENTATION_SOURCE,
            "action_execution_convention": "persistent_command_anchor_integrates_each_increment",
            "raw_isaac_quaternion_order": "xyzw",
            "raw_salvage_convention": "legacy_isaaclab6_xyzw_misread_as_wxyz_tcp_offset",
            "num_actions": 10,
            "max_rotation_increment_rad": 0.25,
            "state_dim": self.dim_proprio,
            "action_dim": self.dim_action,
        }
        for key, expected in checks.items():
            actual = metadata.get(key)
            if actual != expected:
                raise ValueError(
                    f"IsaacLab v6 norm metadata {key}={actual!r}, "
                    f"expected {expected!r}: {path}"
                )
        if metadata.get("action_label_modes") != [self.EXPECTED_ACTION_LABEL_MODE]:
            raise ValueError(
                f"IsaacLab v6 norm stats have invalid action_label_modes: {path}"
            )
        fingerprint = metadata.get("contract_fingerprint_sha256")
        if not isinstance(fingerprint, str) or len(fingerprint) != 64:
            raise ValueError(
                f"IsaacLab v6 norm stats require a SHA-256 contract fingerprint: {path}"
            )


@register_action("isaaclab_reaching_pose_increment")
class IsaacLabReachingPoseIncrementActionSpace(IsaacLabDeltaEEActionSpace):
    """Strict persistent pose-command increments from the v1 reaching collector."""

    EXPECTED_CONVERSION_VERSION = "isaaclab_hdf5_reaching_pose_command_increment_30hz_v1"
    EXPECTED_ROTATION_TARGET = "explicit_pose_controller_command_quaternion_xyzw"
    EXPECTED_ACTION_LABEL_MODE = (
        "base_persistent_pose_command_increment_binary_gripper_30hz"
    )
    EXPECTED_ACTION_TRANSLATION = (
        "robot_base_command_position_minus_persistent_command_anchor_m"
    )
    EXPECTED_ACTION_ROTATION = (
        "robot_base_command_rotation_times_persistent_command_anchor_inv_rotvec_rad"
    )
    EXPECTED_ORIENTATION_SOURCE = "explicit_pose_controller_command_quaternion"
    EXPECTED_ACTION_EXECUTION = (
        "persistent_absolute_pose_command_integrates_each_increment"
    )

    def load_norm_stats(self, path: str):
        LiberoJointActionSpace.load_norm_stats(self, path)
        if self.state_norm_stats is None or self.action_norm_stats is None:
            raise ValueError(f"Reaching pose v1 norm stats require state and actions: {path}")
        self._require_stats_array("state", self.state_norm_stats, self.dim_proprio)
        self._require_stats_array("actions", self.action_norm_stats, self.dim_action)

        with Path(path).open(encoding="utf-8") as handle:
            metadata = json.load(handle).get("metadata")
        if not isinstance(metadata, dict):
            raise ValueError(f"Reaching pose v1 norm stats are missing metadata: {path}")
        checks = {
            "dataset_family": "isaaclab",
            "collection_contract_version": "reaching_pose_command_increment_30hz_v1",
            "conversion_convention_version": self.EXPECTED_CONVERSION_VERSION,
            "action_mode": "isaaclab_reaching_pose_increment",
            "action_label_mode": self.EXPECTED_ACTION_LABEL_MODE,
            "action_translation_convention": self.EXPECTED_ACTION_TRANSLATION,
            "action_rotation_convention": self.EXPECTED_ACTION_ROTATION,
            "action_rotation_target_convention": self.EXPECTED_ROTATION_TARGET,
            "action_temporal_alignment": (
                "handler_returns_actions_t_to_t_plus_horizon_minus_1_last_row_padded"
            ),
            "action_stats_source": self.EXPECTED_ACTION_STATS_SOURCE,
            "coordinate_frame": "robot_base",
            "orientation_supervision_source": self.EXPECTED_ORIENTATION_SOURCE,
            "action_execution_convention": self.EXPECTED_ACTION_EXECUTION,
            "raw_isaac_quaternion_order": "xyzw",
            "raw_salvage_convention": "none",
            "camera_fps": 30.0,
            "control_fps": 30.0,
            "sim_dt": 1.0 / 120.0,
            "control_decimation": 4,
            "max_translation_increment_m": 0.01,
            "max_rotation_increment_rad": 0.01,
            "canonical_orientation_tolerance_rad": 1.0e-6,
            "state_orientation_representation": "robot_base_axis_angle_direct_float32",
            "num_actions": 10,
            "state_dim": self.dim_proprio,
            "action_dim": self.dim_action,
        }
        for key, expected in checks.items():
            actual = metadata.get(key)
            if actual != expected:
                raise ValueError(
                    f"Reaching pose v1 norm metadata {key}={actual!r}, "
                    f"expected {expected!r}: {path}"
                )
        if metadata.get("action_label_modes") != [self.EXPECTED_ACTION_LABEL_MODE]:
            raise ValueError(f"Reaching pose v1 norm stats have invalid action_label_modes: {path}")
        for key in (
            "contract_fingerprint_sha256",
            "pose_controller_fingerprint_sha256",
        ):
            value = metadata.get(key)
            if not isinstance(value, str) or len(value) != 64:
                raise ValueError(f"Reaching pose v1 norm stats require {key}: {path}")


# =============================================================================
# Exports
# =============================================================================
__all__ = [
    "BaseActionSpace",
    "build_action_space",
    "register_action",
    "LiberoJointActionSpace",
    "IsaacLabAbsoluteMacroActionSpace",
    "IsaacLabDeltaEEActionSpace",
    "IsaacLabBaseDeltaEEActionSpace",
    "IsaacLabReachingPoseIncrementActionSpace",
    "ACTION_REGISTRY",
    "NormStats",
    "load_norm_stats",
]
