"""In-process SimVLA model runtime."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch

from franka_wrist_camera_scene.simvla.reaching_pose_v1 import (
    ACTION_MODE,
    IMAGE_SIZE,
    NUM_ACTIONS,
    NUM_VIEWS,
    contract_fingerprint,
    require_sha256,
    validate_contract_metadata,
    validate_language_instruction,
)


@dataclass(frozen=True, slots=True)
class SimVLARuntimeConfig:
    simvla_repo_path: Path
    checkpoint_path: Path
    smolvlm_model_path: Path
    norm_stats_path: Path
    train_meta_path: Path | None = None
    device: str = "cuda"
    action_mode: str = ACTION_MODE
    image_rotation: str = "none"
    num_view_slots: int = NUM_VIEWS
    image_size: int = IMAGE_SIZE
    num_actions: int = NUM_ACTIONS
    inference_steps: int = 10
    predict_uncertainty: bool = True
    uncertainty_parameterization: str | None = None
    num_action_samples: int = 1
    checkpoint_model_sha256: str | None = None
    contract_fingerprint_sha256: str | None = None
    pose_controller_fingerprint_sha256: str | None = None


@dataclass(frozen=True, slots=True)
class SimVLAInferenceOutput:
    actions: np.ndarray
    uncertainty: dict[str, np.ndarray]


class SimVLARuntime:
    """Thin wrapper around the local SimVLA code, with strict shape checks."""

    def __init__(self, config: SimVLARuntimeConfig) -> None:
        self.config = config
        self.model: Any | None = None
        self.processor: Any | None = None
        self.device = torch.device(config.device)

    def load(self) -> None:
        self._require_paths()
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        if self.config.action_mode != ACTION_MODE:
            raise ValueError(
                f"Reaching pose runtime requires action_mode={ACTION_MODE!r}, "
                f"got {self.config.action_mode!r}"
            )
        if self.config.image_rotation != "none":
            raise ValueError("Reaching pose runtime requires image_rotation='none'.")
        if (
            self.config.num_view_slots != NUM_VIEWS
            or self.config.image_size != IMAGE_SIZE
            or self.config.num_actions != NUM_ACTIONS
        ):
            raise ValueError(
                "Reaching pose runtime dimensions differ from the training contract."
            )
        if self.config.inference_steps <= 0:
            raise ValueError("Reaching pose inference_steps must be positive.")
        if self.config.num_action_samples != 1:
            raise ValueError("Reaching pose runtime requires num_action_samples=1.")
        if self.config.predict_uncertainty and self.config.uncertainty_parameterization not in {
            "softplus_raw_variance",
            "log_sigma",
        }:
            raise ValueError(
                "Uncertainty-enabled inference requires an explicit "
                "uncertainty_parameterization."
            )
        controller_fingerprint = require_sha256(
            "pose_controller_fingerprint_sha256",
            self.config.pose_controller_fingerprint_sha256,
        )
        fingerprint = require_sha256(
            "contract_fingerprint_sha256", self.config.contract_fingerprint_sha256
        )
        if fingerprint != contract_fingerprint(controller_fingerprint):
            raise ValueError(
                "Runtime contract fingerprint does not match the pose-controller fingerprint."
            )
        repo = str(self.config.simvla_repo_path)
        if repo not in sys.path:
            sys.path.insert(0, repo)

        import models

        self._validate_imported_models_package(models)
        from models import SmolVLMVLA, SmolVLMVLAProcessor, build_action_space

        self._validate_checkpoint_config()

        self.processor = SmolVLMVLAProcessor.from_pretrained(
            str(self.config.checkpoint_path),
            smolvlm_model_path=str(self.config.smolvlm_model_path),
        )
        self.model = SmolVLMVLA.from_pretrained(
            str(self.config.checkpoint_path),
            action_mode=self.config.action_mode,
            num_actions=self.config.num_actions,
            smolvlm_model_path=str(self.config.smolvlm_model_path),
            predict_uncertainty=self.config.predict_uncertainty,
            trust_remote_code=True,
        ).to(self.device)
        self.model.action_space = build_action_space(
            self.config.action_mode,
            norm_stats_path=str(self.config.norm_stats_path),
        )
        self.model.eval()

    def infer(
        self,
        language_instruction: str,
        image_input: torch.Tensor,
        image_mask: torch.Tensor,
        proprio: np.ndarray,
    ) -> SimVLAInferenceOutput:
        if self.model is None or self.processor is None:
            raise RuntimeError("SimVLARuntime.load() must be called before infer().")
        self._validate_inference_inputs(language_instruction, image_input, image_mask)
        proprio_tensor = torch.as_tensor(proprio, dtype=torch.float32, device=self.device).view(1, -1)
        if proprio_tensor.shape != (1, 8):
            raise ValueError(f"SimVLA proprio must have shape (8,), got {tuple(proprio_tensor.shape)}.")

        encoded = self.processor.encode_language(language_instruction)
        input_ids = encoded["input_ids"].to(self.device)
        image_input = image_input.to(device=self.device, dtype=torch.float32)
        image_mask = image_mask.to(device=self.device, dtype=torch.bool)
        with torch.no_grad():
            if self.config.predict_uncertainty:
                output = self.model.generate_actions_with_uncertainty(
                    input_ids=input_ids,
                    image_input=image_input,
                    image_mask=image_mask,
                    proprio=proprio_tensor,
                    steps=self.config.inference_steps,
                    num_action_samples=self.config.num_action_samples,
                )
                actions = output["action"]
                uncertainty = {
                    key: value.detach().cpu().numpy()
                    for key, value in output.items()
                    if key != "action" and torch.is_tensor(value)
                }
                self._validate_uncertainty(uncertainty)
            else:
                actions = self.model.generate_actions(
                    input_ids=input_ids,
                    image_input=image_input,
                    image_mask=image_mask,
                    proprio=proprio_tensor,
                    steps=self.config.inference_steps,
                )
                uncertainty = {}

        actions_np = actions.squeeze(0).detach().cpu().numpy().astype(np.float32)
        expected_shape = (self.config.num_actions, 7)
        if actions_np.shape != expected_shape:
            raise RuntimeError(f"SimVLA action output must have shape {expected_shape}, got {actions_np.shape}.")
        if not np.all(np.isfinite(actions_np)):
            raise RuntimeError("SimVLA action output contains non-finite values.")
        return SimVLAInferenceOutput(actions=actions_np, uncertainty=uncertainty)

    def _validate_inference_inputs(
        self,
        language_instruction: str,
        image_input: torch.Tensor,
        image_mask: torch.Tensor,
    ) -> None:
        validate_language_instruction(language_instruction)
        expected_image_shape = (
            1,
            self.config.num_view_slots,
            3,
            self.config.image_size,
            self.config.image_size,
        )
        if tuple(image_input.shape) != expected_image_shape:
            raise ValueError(f"image_input must have shape {expected_image_shape}, got {tuple(image_input.shape)}.")
        expected_mask_shape = (1, self.config.num_view_slots)
        if tuple(image_mask.shape) != expected_mask_shape:
            raise ValueError(f"image_mask must have shape {expected_mask_shape}, got {tuple(image_mask.shape)}.")
        if image_mask.bool().tolist() != [[True, True, False]]:
            raise ValueError(f"image_mask must be [[True, True, False]], got {image_mask.bool().tolist()}.")
        if not torch.isfinite(image_input).all():
            raise ValueError("image_input contains NaN or Inf.")

    def _validate_checkpoint_config(self) -> None:
        config_path = self.config.checkpoint_path / "config.json"
        if not config_path.is_file():
            raise FileNotFoundError(config_path)
        checkpoint = json.loads(config_path.read_text(encoding="utf-8"))
        expected = {
            "action_mode": self.config.action_mode,
            "image_rotation": self.config.image_rotation,
            "num_actions": self.config.num_actions,
            "num_views": self.config.num_view_slots,
            "image_size": self.config.image_size,
            "predict_uncertainty": self.config.predict_uncertainty,
            "contract_fingerprint_sha256": self.config.contract_fingerprint_sha256,
        }
        if self.config.predict_uncertainty:
            expected["uncertainty_parameterization"] = (
                self.config.uncertainty_parameterization
            )
        for key, value in expected.items():
            if checkpoint.get(key) != value:
                raise ValueError(f"Checkpoint config {key}={checkpoint.get(key)!r} does not match {value!r}.")
        if self.config.predict_uncertainty:
            expected_model_hash = require_sha256(
                "checkpoint_model_sha256",
                self.config.checkpoint_model_sha256,
            )
            model_path = self.config.checkpoint_path / "model.safetensors"
            if _sha256_file(model_path) != expected_model_hash:
                raise ValueError(
                    f"Checkpoint weights do not match checkpoint_model_sha256: {model_path}"
                )
        self._validate_checkpoint_norm_stats(checkpoint)
        self._validate_checkpoint_train_meta()

    def _validate_checkpoint_norm_stats(self, checkpoint_config: dict[str, Any]) -> None:
        hashes = []
        config_hash = checkpoint_config.get("norm_stats_sha256")
        if config_hash:
            hashes.append(("config.json", config_hash))
        state_path = self.config.checkpoint_path / "state.json"
        if state_path.is_file():
            state = json.loads(state_path.read_text(encoding="utf-8"))
            state_hash = state.get("norm_stats_sha256")
            if state_hash:
                hashes.append(("state.json", state_hash))
            if state.get("contract_fingerprint_sha256") != self.config.contract_fingerprint_sha256:
                raise ValueError(
                    "Checkpoint state.json contract fingerprint does not match runtime config"
                )
        if len(hashes) != 2:
            raise ValueError(
                "Reaching pose checkpoint requires norm_stats_sha256 in config.json and state.json"
            )
        actual_hash = _sha256_file(self.config.norm_stats_path)
        for source, expected_hash in hashes:
            if expected_hash != actual_hash:
                raise ValueError(
                    f"Checkpoint {source} expects norm_stats_sha256={expected_hash}, "
                    f"but {self.config.norm_stats_path} has {actual_hash}."
                )
        norm_payload = json.loads(self.config.norm_stats_path.read_text(encoding="utf-8"))
        metadata = norm_payload.get("metadata")
        if not isinstance(metadata, dict):
            raise ValueError("Reaching pose normalization file is missing metadata")
        validate_contract_metadata(
            metadata,
            require_sha256(
                "pose_controller_fingerprint_sha256",
                self.config.pose_controller_fingerprint_sha256,
            ),
            str(self.config.norm_stats_path),
        )
        if metadata.get("action_label_modes") != [metadata["action_label_mode"]]:
            raise ValueError("Reaching pose norm stats contain inconsistent action_label_modes.")

    def _validate_checkpoint_train_meta(self) -> None:
        if self.config.train_meta_path is None:
            raise ValueError("Reaching pose runtime requires train_meta_path")
        state_path = self.config.checkpoint_path / "state.json"
        if not state_path.is_file():
            raise FileNotFoundError(state_path)
        state = json.loads(state_path.read_text(encoding="utf-8"))
        expected_hash = state.get("train_metas_sha256")
        if not expected_hash:
            raise ValueError("Reaching pose checkpoint state.json is missing train_metas_sha256")
        actual_hash = _sha256_file(self.config.train_meta_path)
        if expected_hash != actual_hash:
            raise ValueError(
                f"Checkpoint state.json expects train_metas_sha256={expected_hash}, "
                f"but {self.config.train_meta_path} has {actual_hash}."
            )
        self._validate_train_meta_contract()

    def _validate_train_meta_contract(self) -> None:
        if self.config.train_meta_path is None:
            raise ValueError("Reaching pose runtime requires train_meta_path")
        payload = json.loads(self.config.train_meta_path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            if not payload:
                raise ValueError("Reaching pose master train meta list is empty.")
            meta_paths = [Path(value) for value in payload]
            missing = [str(path) for path in meta_paths if not path.is_file()]
            if missing:
                raise FileNotFoundError(
                    f"Reaching pose master train meta references missing files: {missing}."
                )
            metas = [json.loads(path.read_text(encoding="utf-8")) for path in meta_paths]
            contexts = [str(path) for path in meta_paths]
        elif isinstance(payload, dict):
            metas = [payload]
            contexts = [str(self.config.train_meta_path)]
        else:
            raise ValueError("Reaching pose train meta must be a mapping or path list.")

        controller_fingerprint = require_sha256(
            "pose_controller_fingerprint_sha256",
            self.config.pose_controller_fingerprint_sha256,
        )
        for meta, context in zip(metas, contexts, strict=True):
            validate_contract_metadata(meta, controller_fingerprint, context)
            expected = {
                "handler": "isaaclab_hdf5",
                "image_rotation": "none",
                "observation_key": ["obs/agentview_rgb", "obs/eye_in_hand_rgb"],
                "strict_errors": True,
            }
            for key, expected_value in expected.items():
                if meta.get(key) != expected_value:
                    raise ValueError(
                        f"{context}: {key}={meta.get(key)!r}, expected {expected_value!r}."
                    )
            if meta.get("lang_aug_map"):
                raise ValueError(
                    f"{context}: language augmentation is forbidden for this strict contract."
                )

    def _validate_imported_models_package(self, models_module: Any) -> None:
        module_file = Path(models_module.__file__).resolve()
        repo_root = self.config.simvla_repo_path.resolve()
        if not module_file.is_relative_to(repo_root):
            raise ImportError(f"Imported models package from {module_file}, expected under {repo_root}.")

    def _validate_uncertainty(self, uncertainty: dict[str, np.ndarray]) -> None:
        required_shapes = {
            "path_variance": (1, self.config.num_actions, 7),
            "last_step_variance": (1, self.config.num_actions, 7),
            "denoise_initial_mean": (1,),
            "denoise_final_mean": (1,),
        }
        missing = sorted(set(required_shapes) - set(uncertainty))
        if missing:
            raise RuntimeError(
                f"SimVLA uncertainty output is missing required keys: {missing}"
            )
        for key, value in uncertainty.items():
            if not np.all(np.isfinite(value)):
                raise RuntimeError(f"SimVLA uncertainty output {key!r} contains non-finite values.")
        for key, expected_shape in required_shapes.items():
            if uncertainty[key].shape != expected_shape:
                raise RuntimeError(
                    f"SimVLA uncertainty output {key!r} must have shape "
                    f"{expected_shape}, got {uncertainty[key].shape}."
                )
        for key in ("path_variance", "last_step_variance"):
            if np.any(uncertainty[key] < 0.0):
                raise RuntimeError(
                    f"SimVLA uncertainty output {key!r} contains negative variance."
                )

    def _require_paths(self) -> None:
        for path in (
            self.config.simvla_repo_path,
            self.config.checkpoint_path,
            self.config.smolvlm_model_path,
            self.config.norm_stats_path,
        ):
            if not path.exists():
                raise FileNotFoundError(path)
        if self.config.train_meta_path is not None and not self.config.train_meta_path.exists():
            raise FileNotFoundError(self.config.train_meta_path)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
