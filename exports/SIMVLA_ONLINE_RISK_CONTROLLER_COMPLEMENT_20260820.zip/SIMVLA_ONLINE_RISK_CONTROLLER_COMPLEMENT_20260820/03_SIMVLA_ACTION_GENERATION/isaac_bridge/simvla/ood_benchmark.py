"""Strict manifests for paired SimVLA reaching OOD benchmarks."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

from franka_wrist_camera_scene.tasks.reaching import ReachingTaskSpec
from franka_wrist_camera_scene.tasks.sampling import (
    ReachingSamplingOptions,
    WorkspaceConstraint,
    parse_lighting_options,
    parse_target_position_set,
    parse_xy_range,
)

MANIFEST_SCHEMA_VERSION = "simvla_reaching_ood_benchmark_v1"


@dataclass(frozen=True, slots=True)
class BenchmarkEpisode:
    benchmark_episode_id: int
    source_episode_id: int
    scene: dict[str, Any]
    scene_fingerprint_sha256: str


@dataclass(frozen=True, slots=True)
class BenchmarkManifest:
    path: Path
    benchmark_name: str
    collection_index: int
    manifest_fingerprint_sha256: str
    episodes: tuple[BenchmarkEpisode, ...]

    def shard(self, offset: int, count: int | None) -> tuple[BenchmarkEpisode, ...]:
        if offset < 0 or offset >= len(self.episodes):
            raise ValueError(
                f"Benchmark offset must be within [0, {len(self.episodes) - 1}], got {offset}."
            )
        end = len(self.episodes) if count is None else offset + count
        if end > len(self.episodes):
            raise ValueError(
                f"Benchmark shard [{offset}, {end}) exceeds {len(self.episodes)} episodes."
            )
        return self.episodes[offset:end]


def canonical_json_sha256(payload: object) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def make_reaching_sampling_options(
    collection_cfg: dict[str, Any],
) -> tuple[ReachingTaskSpec, ReachingSamplingOptions]:
    pose_randomization = collection_cfg["pose_randomization"]
    base_spec_kwargs: dict[str, float] = {}
    for key in (
        "success_threshold_m",
        "max_success_target_displacement_m",
        "reach_dwell_s",
        "direct_reach_max_speed_m_s",
        "reach_surface_clearance_m",
    ):
        if key in collection_cfg:
            base_spec_kwargs[key] = float(collection_cfg[key])

    base_spec = ReachingTaskSpec(**base_spec_kwargs)
    workspace_cfg = pose_randomization["workspace"]
    return base_spec, ReachingSamplingOptions(
        object_xy_range=parse_xy_range(pose_randomization["object_xy_range"]),
        object_origin_xy=base_spec.object_pos_local[:2],
        workspace=WorkspaceConstraint(
            robot_base_xy=tuple(float(value) for value in workspace_cfg["robot_base_xy"]),
            max_distance_m=float(workspace_cfg["max_distance_m"]),
            max_sampling_attempts=int(workspace_cfg["max_sampling_attempts"]),
        ),
        lighting=parse_lighting_options(collection_cfg["lighting_randomization"]),
        target_position_set=parse_target_position_set(
            pose_randomization.get("target_position_set"),
            split=collection_cfg["suite"]["split"],
        ),
    )


def build_scene_payload(source_episode_id: int, scene_assets: Any, episode_plan: Any) -> dict[str, Any]:
    target = scene_assets.object_context
    clutter = [
        {
            "slot_index": slot_index,
            "category_id": str(item["category_id"]),
            "variant_id": str(item["variant_id"]),
            "label": str(item["label"]),
            "source_name": str(item["source_name"]),
            "pos_local": [float(value) for value in item["pos_local"]],
        }
        for slot_index, item in enumerate(episode_plan.clutter_metadata)
    ]
    payload = {
        "source_episode_id": int(source_episode_id),
        "instruction": str(episode_plan.spec.instruction),
        "target": {
            "category_id": str(target.category_id),
            "variant_id": str(target.variant_id),
            "label": str(target.label),
            "source_name": str(scene_assets.target_source_name),
        },
        "target_position_index": int(episode_plan.sample.target_position_index),
        "object_xy_offset": [
            float(value) for value in episode_plan.sample.object_xy_offset
        ],
        "clutter_position_index": int(episode_plan.clutter_position_index),
        "clutter": clutter,
        "lighting": {
            "intensity": float(episode_plan.sample.light_intensity),
            "color": [float(value) for value in episode_plan.sample.light_color],
        },
    }
    validate_scene_payload(payload)
    return payload


def validate_scene_payload(scene: dict[str, Any]) -> None:
    target = scene["target"]
    expected_instruction = f"reach the {target['label']}"
    if scene["instruction"] != expected_instruction:
        raise ValueError(
            f"Prompt mismatch: expected {expected_instruction!r}, got {scene['instruction']!r}."
        )

    target_category = str(target["category_id"])
    target_label = str(target["label"])
    for clutter_item in scene["clutter"]:
        clutter_category = str(clutter_item["category_id"])
        clutter_label = str(clutter_item["label"])
        if clutter_category == target_category:
            raise ValueError(
                f"Target category {target_category!r} appears in clutter slot "
                f"{clutter_item['slot_index']}."
            )
        if clutter_label == target_label:
            raise ValueError(
                f"Target label {target_label!r} appears in clutter slot "
                f"{clutter_item['slot_index']} as category {clutter_category!r}."
            )


def build_manifest_payload(
    benchmark_name: str,
    collection_config: str,
    collection_index: int,
    seed: int,
    episodes: list[dict[str, Any]],
    provenance: dict[str, Any],
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "benchmark_name": benchmark_name,
        "collection_config": collection_config,
        "collection_index": collection_index,
        "seed": seed,
        "provenance": provenance,
        "episodes": episodes,
    }
    payload["manifest_fingerprint_sha256"] = canonical_json_sha256(payload)
    return payload


def load_benchmark_manifest(path: Path) -> BenchmarkManifest:
    resolved_path = path.expanduser().resolve()
    if not resolved_path.is_file():
        raise FileNotFoundError(f"Benchmark manifest not found: {resolved_path}")
    payload = json.loads(resolved_path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != MANIFEST_SCHEMA_VERSION:
        raise ValueError(
            f"{resolved_path}: expected schema {MANIFEST_SCHEMA_VERSION!r}, "
            f"got {payload.get('schema_version')!r}."
        )

    expected_fingerprint = str(payload.get("manifest_fingerprint_sha256", ""))
    fingerprint_payload = dict(payload)
    fingerprint_payload.pop("manifest_fingerprint_sha256", None)
    actual_fingerprint = canonical_json_sha256(fingerprint_payload)
    if actual_fingerprint != expected_fingerprint:
        raise ValueError(
            f"{resolved_path}: manifest fingerprint mismatch; "
            f"expected={expected_fingerprint}, actual={actual_fingerprint}."
        )

    raw_episodes = payload.get("episodes")
    if not isinstance(raw_episodes, list) or not raw_episodes:
        raise ValueError(f"{resolved_path}: episodes must be a non-empty list.")

    episodes: list[BenchmarkEpisode] = []
    fingerprints: set[str] = set()
    for expected_id, raw_episode in enumerate(raw_episodes):
        benchmark_episode_id = int(raw_episode["benchmark_episode_id"])
        if benchmark_episode_id != expected_id:
            raise ValueError(
                f"{resolved_path}: expected benchmark_episode_id={expected_id}, "
                f"got {benchmark_episode_id}."
            )
        scene = raw_episode["scene"]
        validate_scene_payload(scene)
        expected_scene_fingerprint = str(raw_episode["scene_fingerprint_sha256"])
        actual_scene_fingerprint = canonical_json_sha256(scene)
        if actual_scene_fingerprint != expected_scene_fingerprint:
            raise ValueError(
                f"{resolved_path}: episode {expected_id} scene fingerprint mismatch."
            )
        if expected_scene_fingerprint in fingerprints:
            raise ValueError(
                f"{resolved_path}: duplicate scene fingerprint at episode {expected_id}."
            )
        fingerprints.add(expected_scene_fingerprint)
        episodes.append(
            BenchmarkEpisode(
                benchmark_episode_id=benchmark_episode_id,
                source_episode_id=int(scene["source_episode_id"]),
                scene=scene,
                scene_fingerprint_sha256=expected_scene_fingerprint,
            )
        )

    return BenchmarkManifest(
        path=resolved_path,
        benchmark_name=str(payload["benchmark_name"]),
        collection_index=int(payload["collection_index"]),
        manifest_fingerprint_sha256=expected_fingerprint,
        episodes=tuple(episodes),
    )


def require_scene_matches_manifest(
    episode: BenchmarkEpisode,
    scene_assets: Any,
    episode_plan: Any,
) -> None:
    actual_scene = build_scene_payload(
        source_episode_id=episode.source_episode_id,
        scene_assets=scene_assets,
        episode_plan=episode_plan,
    )
    actual_fingerprint = canonical_json_sha256(actual_scene)
    if actual_fingerprint != episode.scene_fingerprint_sha256:
        raise ValueError(
            f"Benchmark episode {episode.benchmark_episode_id} scene mismatch: "
            f"expected={episode.scene_fingerprint_sha256}, actual={actual_fingerprint}."
        )
