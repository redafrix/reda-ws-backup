"""Geometry and action conversions matching the SimVLA IsaacLab dataset."""

from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from scipy.spatial.transform import Rotation as R

from franka_wrist_camera_scene.simvla.constants import DEFAULT_SIMVLA_CONVENTION, SimVLADataConvention


@dataclass(frozen=True, slots=True)
class SimVLAProprioSource:
    ee_pos_w: np.ndarray
    ee_quat_wxyz: np.ndarray
    robot_base_pos_w: np.ndarray
    robot_base_quat_wxyz: np.ndarray
    finger_opening_m: float


@dataclass(frozen=True, slots=True)
class DecodedSimVLAAction:
    target_pos_w: np.ndarray
    target_quat_wxyz: np.ndarray
    finger_opening_m: float


def quat_wxyz_to_xyzw(quat_wxyz: np.ndarray) -> np.ndarray:
    quat = np.asarray(quat_wxyz, dtype=np.float64)
    if quat.shape[-1] != 4:
        raise ValueError(f"Quaternion last dimension must be 4, got {quat.shape}.")
    return np.concatenate((quat[..., 1:4], quat[..., 0:1]), axis=-1)


def quat_xyzw_to_wxyz(quat_xyzw: np.ndarray) -> np.ndarray:
    quat = np.asarray(quat_xyzw, dtype=np.float64)
    if quat.shape[-1] != 4:
        raise ValueError(f"Quaternion last dimension must be 4, got {quat.shape}.")
    return np.concatenate((quat[..., 3:4], quat[..., 0:3]), axis=-1)


def require_finite_vector(name: str, values: np.ndarray, shape: tuple[int, ...]) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float64)
    if arr.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {arr.shape}.")
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} contains non-finite values: {arr}.")
    return arr


def normalize_quat_wxyz(name: str, values: np.ndarray, shape: tuple[int, ...] = (4,)) -> np.ndarray:
    quat = require_finite_vector(name, values, shape).copy()
    norm = np.linalg.norm(quat, axis=-1, keepdims=True)
    if np.any(norm <= 1e-8):
        raise ValueError(f"{name} contains near-zero quaternion norm.")
    return quat / norm


def target_quat_or_identity_delta(
    target_quat_wxyz: np.ndarray,
    live_quat_wxyz: np.ndarray,
    *,
    allow_nan_target_quat: bool = False,
) -> np.ndarray:
    """Normalize target WXYZ quaternion, optionally treating all-NaN as zero rotation."""

    target = np.asarray(target_quat_wxyz, dtype=np.float64)
    if target.shape != (4,):
        raise ValueError(f"target_quat_wxyz must have shape (4,), got {target.shape}.")
    if np.all(np.isnan(target)):
        if not allow_nan_target_quat:
            raise ValueError("target_quat_wxyz is all-NaN; zero-rotation fallback is not enabled.")
        return normalize_quat_wxyz("live_quat_wxyz", live_quat_wxyz)
    if np.any(~np.isfinite(target)):
        raise ValueError(f"target_quat_wxyz contains partial/non-finite values: {target}.")
    return normalize_quat_wxyz("target_quat_wxyz", target)


def libero_euler_xyz_from_rotation(rot: R) -> np.ndarray:
    euler = rot.as_euler("xyz").astype(np.float32)
    if float(euler[0]) < -math.pi / 2.0:
        euler[0] += 2.0 * math.pi
    return euler


def euler_xyz_to_axis_angle(euler_xyz: np.ndarray) -> np.ndarray:
    quat_xyzw = R.from_euler("xyz", euler_xyz).as_quat()
    return quat_xyzw_to_axis_angle(quat_xyzw)


def quat_xyzw_to_axis_angle(quat_xyzw: np.ndarray) -> np.ndarray:
    quat = require_finite_vector("quat_xyzw", quat_xyzw, (4,)).copy()
    quat[3] = min(1.0, max(-1.0, float(quat[3])))
    den = math.sqrt(max(0.0, 1.0 - float(quat[3]) * float(quat[3])))
    if math.isclose(den, 0.0):
        return np.zeros(3, dtype=np.float32)
    return ((quat[:3] * 2.0 * math.acos(float(quat[3]))) / den).astype(np.float32)


def binary_gripper_action(
    finger_opening_m: float,
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
) -> float:
    """Return the dataset gripper command convention: -1 open, +1 close."""
    opening = float(finger_opening_m)
    if not math.isfinite(opening):
        raise ValueError(f"finger_opening_m must be finite, got {finger_opening_m}.")
    midpoint = 0.5 * (float(convention.open_finger_m) + float(convention.closed_finger_m))
    return 1.0 if opening <= midpoint else -1.0


def finger_opening_from_binary_gripper_action(
    gripper_action: float,
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
) -> float:
    """Decode -1 open / +1 close into a physical Franka finger opening."""
    return float(convention.closed_finger_m if float(gripper_action) >= 0.0 else convention.open_finger_m)


def encode_simvla_proprio(source: SimVLAProprioSource) -> np.ndarray:
    ee_pos = require_finite_vector("ee_pos_w", source.ee_pos_w, (3,))
    base_pos = require_finite_vector("robot_base_pos_w", source.robot_base_pos_w, (3,))
    quat_wxyz = normalize_quat_wxyz("ee_quat_wxyz", source.ee_quat_wxyz)
    base_quat_wxyz = normalize_quat_wxyz(
        "robot_base_quat_wxyz", source.robot_base_quat_wxyz
    )
    if not math.isfinite(float(source.finger_opening_m)):
        raise ValueError(f"finger_opening_m must be finite, got {source.finger_opening_m}.")

    base_rotation_w = R.from_quat(quat_wxyz_to_xyzw(base_quat_wxyz))
    ee_rotation_w = R.from_quat(quat_wxyz_to_xyzw(quat_wxyz))
    ee_rotation_base = base_rotation_w.inv() * ee_rotation_w
    ee_ori = libero_euler_xyz_from_rotation(ee_rotation_base)
    axis_angle = euler_xyz_to_axis_angle(ee_ori)
    opening = float(source.finger_opening_m)
    gripper = np.array((opening, -opening), dtype=np.float32)
    ee_pos_base = base_rotation_w.inv().apply(ee_pos - base_pos).astype(np.float32)
    return np.concatenate((ee_pos_base, axis_angle, gripper), axis=0)


def decode_simvla_base_delta_action(
    action: np.ndarray,
    source: SimVLAProprioSource,
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
) -> DecodedSimVLAAction:
    """Decode one v4 robot-base delta against the current live EE pose."""

    action_arr = require_finite_vector("action", action, (7,))
    ee_pos_w = require_finite_vector("ee_pos_w", source.ee_pos_w, (3,))
    ee_quat_wxyz = normalize_quat_wxyz("ee_quat_wxyz", source.ee_quat_wxyz)
    base_quat_wxyz = normalize_quat_wxyz(
        "robot_base_quat_wxyz", source.robot_base_quat_wxyz
    )
    require_finite_vector("robot_base_pos_w", source.robot_base_pos_w, (3,))

    base_rotation_w = R.from_quat(quat_wxyz_to_xyzw(base_quat_wxyz))
    live_rotation_w = R.from_quat(quat_wxyz_to_xyzw(ee_quat_wxyz))
    live_rotation_base = base_rotation_w.inv() * live_rotation_w
    relative_rotation_base = R.from_rotvec(action_arr[3:6])
    target_rotation_base = relative_rotation_base * live_rotation_base
    target_rotation_w = base_rotation_w * target_rotation_base
    finger_opening = finger_opening_from_binary_gripper_action(
        action_arr[6], convention=convention
    )
    return DecodedSimVLAAction(
        target_pos_w=(ee_pos_w + base_rotation_w.apply(action_arr[:3])).astype(np.float32),
        target_quat_wxyz=quat_xyzw_to_wxyz(target_rotation_w.as_quat()).astype(np.float32),
        finger_opening_m=finger_opening,
    )


def decode_simvla_action(
    action: np.ndarray,
    ee_pos_w: np.ndarray,
    ee_quat_wxyz: np.ndarray,
    env_origin_w: np.ndarray | None = None,
    action_mode: str = "isaaclab_delta_ee",
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
) -> DecodedSimVLAAction:
    action_arr = require_finite_vector("action", action, (7,))
    ee_pos = require_finite_vector("ee_pos_w", ee_pos_w, (3,))
    ee_quat = normalize_quat_wxyz("ee_quat_wxyz", ee_quat_wxyz)

    if action_mode == "isaaclab_absolute_macro":
        if env_origin_w is None:
            raise ValueError("env_origin_w is required for isaaclab_absolute_macro actions.")
        env_origin = require_finite_vector("env_origin_w", env_origin_w, (3,))
        target_pos = env_origin + action_arr[:3]
        target_quat = quat_xyzw_to_wxyz(R.from_euler("xyz", action_arr[3:6]).as_quat()).astype(np.float32)
        finger_opening = (
            convention.closed_finger_m if float(action_arr[6]) >= 0.0 else convention.open_finger_m
        )
    elif action_mode in {"isaaclab_delta_ee", "libero_joint"}:
        decoded = decode_delta_ee_action(action_arr, ee_pos, ee_quat, convention=convention)
        return decoded
    else:
        raise ValueError(f"Unsupported SimVLA action_mode={action_mode!r}.")
    return DecodedSimVLAAction(
        target_pos_w=target_pos.astype(np.float32),
        target_quat_wxyz=target_quat,
        finger_opening_m=float(finger_opening),
    )


def encode_delta_ee_action(
    target_pos_w: np.ndarray,
    target_quat_wxyz: np.ndarray,
    finger_opening_m: float,
    anchor_ee_pos_w: np.ndarray,
    anchor_ee_quat_wxyz: np.ndarray,
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
    allow_nan_target_quat: bool = False,
) -> np.ndarray:
    """Encode one absolute Cartesian command as an IsaacLab world/left delta action."""

    target_pos = require_finite_vector("target_pos_w", target_pos_w, (3,))
    anchor_quat = normalize_quat_wxyz("anchor_ee_quat_wxyz", anchor_ee_quat_wxyz)
    target_quat = target_quat_or_identity_delta(
        target_quat_wxyz,
        anchor_quat,
        allow_nan_target_quat=allow_nan_target_quat,
    )
    anchor_pos = require_finite_vector("anchor_ee_pos_w", anchor_ee_pos_w, (3,))
    gripper_action = binary_gripper_action(finger_opening_m, convention=convention)

    anchor_rot = R.from_quat(quat_wxyz_to_xyzw(anchor_quat))
    target_rot = R.from_quat(quat_wxyz_to_xyzw(target_quat))
    relative_rotvec = (target_rot * anchor_rot.inv()).as_rotvec()
    return np.concatenate(
        (
            (target_pos - anchor_pos).astype(np.float32),
            relative_rotvec.astype(np.float32),
            np.asarray([gripper_action], dtype=np.float32),
        ),
        axis=0,
    )


def decode_delta_ee_action(
    action: np.ndarray,
    ee_pos_w: np.ndarray,
    ee_quat_wxyz: np.ndarray,
    convention: SimVLADataConvention = DEFAULT_SIMVLA_CONVENTION,
) -> DecodedSimVLAAction:
    """Decode an IsaacLab world/left delta action into an absolute Cartesian command."""

    action_arr = require_finite_vector("action", action, (7,))
    ee_pos = require_finite_vector("ee_pos_w", ee_pos_w, (3,))
    ee_quat = normalize_quat_wxyz("ee_quat_wxyz", ee_quat_wxyz)
    current_rot = R.from_quat(quat_wxyz_to_xyzw(ee_quat))
    relative_rot = R.from_rotvec(action_arr[3:6])
    finger_opening = finger_opening_from_binary_gripper_action(action_arr[6], convention=convention)
    return DecodedSimVLAAction(
        target_pos_w=(ee_pos + action_arr[:3]).astype(np.float32),
        target_quat_wxyz=quat_xyzw_to_wxyz((relative_rot * current_rot).as_quat()).astype(np.float32),
        finger_opening_m=finger_opening,
    )


def encode_delta_ee_action_chunk(
    *,
    ee_pos_w: np.ndarray,
    ee_quat_wxyz: np.ndarray,
    target_pos_w: np.ndarray,
    target_quat_wxyz: np.ndarray,
    finger_opening_m: np.ndarray,
    start_index: int,
    num_actions: int,
    allow_nan_target_quat: bool = False,
) -> np.ndarray:
    """Build a raw future action chunk without chunk-start reanchoring."""

    if num_actions <= 0:
        raise ValueError(f"num_actions must be positive, got {num_actions}.")
    target_pos = np.asarray(target_pos_w, dtype=np.float64)
    target_quat = np.asarray(target_quat_wxyz, dtype=np.float64)
    ee_pos = np.asarray(ee_pos_w, dtype=np.float64)
    ee_quat = np.asarray(ee_quat_wxyz, dtype=np.float64)
    finger = np.asarray(finger_opening_m, dtype=np.float64).reshape(-1)
    if ee_pos.ndim != 2 or ee_pos.shape[1] != 3:
        raise ValueError(f"ee_pos_w must have shape [T, 3], got {ee_pos.shape}.")
    if ee_quat.ndim != 2 or ee_quat.shape[1] != 4:
        raise ValueError(f"ee_quat_wxyz must have shape [T, 4], got {ee_quat.shape}.")
    if target_pos.ndim != 2 or target_pos.shape[1] != 3:
        raise ValueError(f"target_pos_w must have shape [T, 3], got {target_pos.shape}.")
    if target_quat.ndim != 2 or target_quat.shape[1] != 4:
        raise ValueError(f"target_quat_wxyz must have shape [T, 4], got {target_quat.shape}.")
    if not (ee_pos.shape[0] == ee_quat.shape[0] == target_pos.shape[0] == target_quat.shape[0] == finger.shape[0]):
        raise ValueError("EE pose, target pose, and finger action arrays must have the same length.")
    if start_index < 0 or start_index >= target_pos.shape[0]:
        raise IndexError(f"start_index must be in [0, {target_pos.shape[0] - 1}], got {start_index}.")

    chunk = np.empty((num_actions, 7), dtype=np.float32)
    for offset in range(num_actions):
        idx = min(start_index + offset, target_pos.shape[0] - 1)
        chunk[offset] = encode_delta_ee_action(
            target_pos_w=target_pos[idx],
            target_quat_wxyz=target_quat[idx],
            finger_opening_m=float(finger[idx]),
            anchor_ee_pos_w=ee_pos[idx],
            anchor_ee_quat_wxyz=ee_quat[idx],
            convention=DEFAULT_SIMVLA_CONVENTION,
            allow_nan_target_quat=allow_nan_target_quat,
        )
    return chunk
