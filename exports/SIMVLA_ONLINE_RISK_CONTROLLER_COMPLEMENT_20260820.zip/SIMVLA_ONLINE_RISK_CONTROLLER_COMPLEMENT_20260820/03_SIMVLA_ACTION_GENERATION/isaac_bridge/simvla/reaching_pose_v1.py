"""Strict SimVLA inference contract for reaching pose-command increments."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from typing import Any, Mapping

import numpy as np
from scipy.spatial.transform import Rotation

from franka_wrist_camera_scene.control.reaching_pose_actions import (
    PoseCommandAnchor,
    RobotBaseFrame,
    decode_command_increment,
)
from franka_wrist_camera_scene.simvla.geometry import (
    DecodedSimVLAAction,
    SimVLAProprioSource,
    normalize_quat_wxyz,
    quat_wxyz_to_xyzw,
    quat_xyzw_to_wxyz,
    require_finite_vector,
)

COLLECTION_CONTRACT_VERSION = "reaching_pose_command_increment_30hz_v1"
CONVERSION_VERSION = "isaaclab_hdf5_reaching_pose_command_increment_30hz_v1"
ACTION_MODE = "isaaclab_reaching_pose_increment"
ACTION_LABEL_MODE = "base_persistent_pose_command_increment_binary_gripper_30hz"
ACTION_TRANSLATION_CONVENTION = (
    "robot_base_command_position_minus_persistent_command_anchor_m"
)
ACTION_ROTATION_CONVENTION = (
    "robot_base_command_rotation_times_persistent_command_anchor_inv_rotvec_rad"
)
ACTION_ROTATION_TARGET_CONVENTION = "explicit_pose_controller_command_quaternion_xyzw"
ORIENTATION_SUPERVISION_SOURCE = "explicit_pose_controller_command_quaternion"
ACTION_EXECUTION_CONVENTION = (
    "persistent_absolute_pose_command_integrates_each_increment"
)
ACTION_TEMPORAL_ALIGNMENT = (
    "handler_returns_actions_t_to_t_plus_horizon_minus_1_last_row_padded"
)
ACTION_STATS_SOURCE = "handler_raw_rows_t_to_t_plus_horizon_minus_1_last_row_padded"
COORDINATE_FRAME = "robot_base"
RAW_QUATERNION_ORDER = "xyzw"
RAW_SALVAGE_CONVENTION = "none"
STATE_ACTION_ALIGNMENT = "same_tick_pre_sim_step"
STATE_ORIENTATION_REPRESENTATION = "robot_base_axis_angle_direct_float32"
IMAGE_PREPROCESS = (
    "agent_crop_yx=(0:480,80:560);agent_resize=384x384_bicubic;"
    "wrist_passthrough_384x384_required;uint8;no_pre_rotation"
)
CAMERA_FPS = 30.0
CONTROL_FPS = 30.0
SIM_DT = 1.0 / 120.0
CONTROL_DECIMATION = 4
NUM_ACTIONS = 10
NUM_VIEWS = 3
IMAGE_SIZE = 384
STATE_DIM = 8
ACTION_DIM = 7
GRIPPER_CLOSE_THRESHOLD_M = 0.02
OPEN_FINGER_M = 0.04
CLOSED_FINGER_M = 0.0
MAX_TRANSLATION_INCREMENT_M = 0.01
MAX_ROTATION_INCREMENT_RAD = 0.01
CANONICAL_ORIENTATION_TOLERANCE_RAD = 1.0e-6


def require_sha256(name: str, value: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError(f"{name} must contain 64 hexadecimal characters.")
    try:
        int(value, 16)
    except ValueError as exc:
        raise ValueError(f"{name} must be hexadecimal.") from exc
    return value


def contract_payload(controller_fingerprint: str) -> dict[str, Any]:
    fingerprint = require_sha256(
        "pose_controller_fingerprint_sha256", controller_fingerprint
    )
    return {
        "collection_contract_version": COLLECTION_CONTRACT_VERSION,
        "conversion_convention_version": CONVERSION_VERSION,
        "action_mode": ACTION_MODE,
        "action_label_mode": ACTION_LABEL_MODE,
        "action_translation_convention": ACTION_TRANSLATION_CONVENTION,
        "action_rotation_convention": ACTION_ROTATION_CONVENTION,
        "action_rotation_target_convention": ACTION_ROTATION_TARGET_CONVENTION,
        "orientation_supervision_source": ORIENTATION_SUPERVISION_SOURCE,
        "action_execution_convention": ACTION_EXECUTION_CONVENTION,
        "action_temporal_alignment": ACTION_TEMPORAL_ALIGNMENT,
        "action_stats_source": ACTION_STATS_SOURCE,
        "coordinate_frame": COORDINATE_FRAME,
        "raw_isaac_quaternion_order": RAW_QUATERNION_ORDER,
        "raw_salvage_convention": RAW_SALVAGE_CONVENTION,
        "state_action_alignment": STATE_ACTION_ALIGNMENT,
        "state_orientation_representation": STATE_ORIENTATION_REPRESENTATION,
        "image_preprocess": IMAGE_PREPROCESS,
        "camera_fps": CAMERA_FPS,
        "control_fps": CONTROL_FPS,
        "sim_dt": SIM_DT,
        "control_decimation": CONTROL_DECIMATION,
        "num_actions": NUM_ACTIONS,
        "state_dim": STATE_DIM,
        "action_dim": ACTION_DIM,
        "gripper_close_threshold_m": GRIPPER_CLOSE_THRESHOLD_M,
        "max_translation_increment_m": MAX_TRANSLATION_INCREMENT_M,
        "max_rotation_increment_rad": MAX_ROTATION_INCREMENT_RAD,
        "canonical_orientation_tolerance_rad": CANONICAL_ORIENTATION_TOLERANCE_RAD,
        "pose_controller_fingerprint_sha256": fingerprint,
    }


def contract_fingerprint(controller_fingerprint: str) -> str:
    serialized = json.dumps(
        contract_payload(controller_fingerprint),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(serialized.encode("ascii")).hexdigest()


def validate_contract_metadata(
    payload: Mapping[str, Any], controller_fingerprint: str, context: str
) -> str:
    expected = contract_payload(controller_fingerprint)
    for key, expected_value in expected.items():
        actual = payload.get(key)
        if actual != expected_value:
            raise ValueError(
                f"{context}: {key}={actual!r}, expected {expected_value!r}."
            )
    expected_fingerprint = contract_fingerprint(controller_fingerprint)
    actual_fingerprint = payload.get("contract_fingerprint_sha256")
    if actual_fingerprint != expected_fingerprint:
        raise ValueError(
            f"{context}: contract_fingerprint_sha256={actual_fingerprint!r}, "
            f"expected {expected_fingerprint!r}."
        )
    return expected_fingerprint


def validate_language_instruction(value: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError("language_instruction must be a non-empty string.")
    if value != value.strip():
        raise ValueError("language_instruction must not contain surrounding whitespace.")
    return value


def encode_reaching_pose_proprio(source: SimVLAProprioSource) -> np.ndarray:
    ee_position_w = require_finite_vector("ee_pos_w", source.ee_pos_w, (3,))
    base_position_w = require_finite_vector(
        "robot_base_pos_w", source.robot_base_pos_w, (3,)
    )
    ee_quaternion_wxyz = normalize_quat_wxyz("ee_quat_wxyz", source.ee_quat_wxyz)
    base_quaternion_wxyz = normalize_quat_wxyz(
        "robot_base_quat_wxyz", source.robot_base_quat_wxyz
    )
    opening = float(source.finger_opening_m)
    if not math.isfinite(opening) or not 0.0 <= opening <= 0.08:
        raise ValueError(f"finger_opening_m is outside [0, 0.08]: {opening}.")

    base_rotation_w = Rotation.from_quat(quat_wxyz_to_xyzw(base_quaternion_wxyz))
    ee_rotation_w = Rotation.from_quat(quat_wxyz_to_xyzw(ee_quaternion_wxyz))
    ee_position_base = base_rotation_w.inv().apply(ee_position_w - base_position_w)
    ee_axis_angle_base = (base_rotation_w.inv() * ee_rotation_w).as_rotvec()
    return np.concatenate(
        (
            ee_position_base.astype(np.float32),
            ee_axis_angle_base.astype(np.float32),
            np.asarray((opening, -opening), dtype=np.float32),
        )
    )


@dataclass(slots=True)
class PersistentPoseCommandIntegrator:
    """Decode model rows against one persistent command anchor per episode."""

    _anchor: PoseCommandAnchor | None = None
    _base_frame: RobotBaseFrame | None = None

    def reset(self, source: SimVLAProprioSource) -> None:
        position = require_finite_vector("ee_pos_w", source.ee_pos_w, (3,)).copy()
        quaternion_wxyz = normalize_quat_wxyz("ee_quat_wxyz", source.ee_quat_wxyz)
        base_position = require_finite_vector(
            "robot_base_pos_w", source.robot_base_pos_w, (3,)
        ).copy()
        base_quaternion = normalize_quat_wxyz(
            "robot_base_quat_wxyz", source.robot_base_quat_wxyz
        ).copy()
        self._anchor = PoseCommandAnchor(
            position_w=position,
            quaternion_xyzw=quat_wxyz_to_xyzw(quaternion_wxyz),
        )
        self._base_frame = RobotBaseFrame(
            position_w=base_position,
            quaternion_wxyz=base_quaternion,
        )

    def decode(self, action: np.ndarray) -> DecodedSimVLAAction:
        if self._anchor is None or self._base_frame is None:
            raise RuntimeError("PersistentPoseCommandIntegrator.reset() must run first.")
        action_array = require_finite_vector("action", action, (ACTION_DIM,))
        translation_norm = float(np.linalg.norm(action_array[:3]))
        rotation_norm = float(np.linalg.norm(action_array[3:6]))
        if translation_norm > MAX_TRANSLATION_INCREMENT_M:
            raise ValueError(
                "SimVLA translation increment exceeds the training contract: "
                f"{translation_norm:.9g} > {MAX_TRANSLATION_INCREMENT_M:.9g} m."
            )
        if rotation_norm > MAX_ROTATION_INCREMENT_RAD:
            raise ValueError(
                "SimVLA rotation increment exceeds the training contract: "
                f"{rotation_norm:.9g} > {MAX_ROTATION_INCREMENT_RAD:.9g} rad."
            )
        decoded = decode_command_increment(
            action_array,
            self._anchor,
            self._base_frame,
        )
        self._anchor = decoded.anchor
        return DecodedSimVLAAction(
            target_pos_w=decoded.anchor.position_w.astype(np.float32),
            target_quat_wxyz=quat_xyzw_to_wxyz(
                decoded.anchor.quaternion_xyzw
            ).astype(np.float32),
            finger_opening_m=float(decoded.finger_opening_m),
        )
