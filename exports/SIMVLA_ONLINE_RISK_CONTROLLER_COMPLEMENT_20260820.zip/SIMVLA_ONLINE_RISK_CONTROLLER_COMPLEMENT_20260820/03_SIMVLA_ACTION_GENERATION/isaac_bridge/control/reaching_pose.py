"""Strict shared controller contract for pose-controlled reaching."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any

import torch

from franka_wrist_camera_scene.utils.quaternion import quat_xyzw_to_wxyz_torch

REACHING_POSE_CONTRACT_VERSION = "reaching_pose_command_increment_30hz_v1"
REACHING_POSE_EXECUTION = "persistent_absolute_pose_command_integrates_each_increment"
RAW_QUATERNION_ORDER = "xyzw"


@dataclass(frozen=True, slots=True)
class ReachingPoseControllerContract:
    version: str
    canonical_ee_quat_base_wxyz: tuple[float, float, float, float]
    dls_lambda: float
    singular_value_threshold: float
    singularity_dls_lambda: float
    max_joint_step_rad: float
    joint_step_gain: float
    minimum_joint_limit_margin_rad: float
    pose_error_weights: tuple[float, float, float, float, float, float]
    posture_joint_targets_rad: tuple[tuple[str, float], ...]
    posture_gain: float
    posture_damping: float
    ready_duration_s: float
    initial_orientation_tolerance_rad: float
    tracking_orientation_tolerance_rad: float
    tracking_position_tolerance_m: float

    def __post_init__(self) -> None:
        if self.version != REACHING_POSE_CONTRACT_VERSION:
            raise ValueError(
                f"Expected pose controller version {REACHING_POSE_CONTRACT_VERSION!r}, "
                f"got {self.version!r}."
            )
        quat = torch.tensor(self.canonical_ee_quat_base_wxyz, dtype=torch.float64)
        if quat.shape != (4,) or not torch.isfinite(quat).all():
            raise ValueError("canonical_ee_quat_base_wxyz must be a finite four-vector.")
        if not torch.allclose(torch.linalg.vector_norm(quat), torch.tensor(1.0, dtype=quat.dtype), atol=1e-6):
            raise ValueError("canonical_ee_quat_base_wxyz must be unit length within 1e-6.")
        positive_values = {
            "dls_lambda": self.dls_lambda,
            "singular_value_threshold": self.singular_value_threshold,
            "singularity_dls_lambda": self.singularity_dls_lambda,
            "max_joint_step_rad": self.max_joint_step_rad,
            "joint_step_gain": self.joint_step_gain,
            "minimum_joint_limit_margin_rad": self.minimum_joint_limit_margin_rad,
            "posture_damping": self.posture_damping,
            "ready_duration_s": self.ready_duration_s,
            "initial_orientation_tolerance_rad": self.initial_orientation_tolerance_rad,
            "tracking_orientation_tolerance_rad": self.tracking_orientation_tolerance_rad,
            "tracking_position_tolerance_m": self.tracking_position_tolerance_m,
        }
        invalid = {name: value for name, value in positive_values.items() if value <= 0.0}
        if invalid:
            raise ValueError(f"Pose controller values must be positive: {invalid}.")
        if self.singularity_dls_lambda < self.dls_lambda:
            raise ValueError("singularity_dls_lambda must be at least dls_lambda.")
        if self.posture_gain < 0.0:
            raise ValueError("posture_gain must be non-negative.")
        posture_targets = dict(self.posture_joint_targets_rad)
        if len(posture_targets) != len(self.posture_joint_targets_rad):
            raise ValueError("posture_joint_targets_rad contains duplicate joint names.")
        invalid_posture_targets = {
            name: value
            for name, value in posture_targets.items()
            if not name.startswith("panda_joint") or not torch.isfinite(torch.tensor(value))
        }
        if invalid_posture_targets:
            raise ValueError(f"Invalid posture joint targets: {invalid_posture_targets}.")
        if self.posture_gain > 0.0 and not posture_targets:
            raise ValueError("Positive posture_gain requires posture_joint_targets_rad.")
        if any(weight <= 0.0 for weight in self.pose_error_weights):
            raise ValueError("pose_error_weights must all be positive.")

    def to_payload(self) -> dict[str, Any]:
        """Return the canonical JSON-compatible controller contract."""
        return {
            "version": self.version,
            "canonical_ee_quat_base_wxyz": list(self.canonical_ee_quat_base_wxyz),
            "dls_lambda": self.dls_lambda,
            "singular_value_threshold": self.singular_value_threshold,
            "singularity_dls_lambda": self.singularity_dls_lambda,
            "max_joint_step_rad": self.max_joint_step_rad,
            "joint_step_gain": self.joint_step_gain,
            "minimum_joint_limit_margin_rad": self.minimum_joint_limit_margin_rad,
            "pose_error_weights": list(self.pose_error_weights),
            "posture_joint_targets_rad": dict(self.posture_joint_targets_rad),
            "posture_gain": self.posture_gain,
            "posture_damping": self.posture_damping,
            "ready_duration_s": self.ready_duration_s,
            "initial_orientation_tolerance_rad": self.initial_orientation_tolerance_rad,
            "tracking_orientation_tolerance_rad": self.tracking_orientation_tolerance_rad,
            "tracking_position_tolerance_m": self.tracking_position_tolerance_m,
        }

    @property
    def fingerprint_sha256(self) -> str:
        """Hash the canonical controller contract for cross-stack validation."""
        encoded = json.dumps(
            self.to_payload(),
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()


_CONTRACT_KEYS = {
    "version",
    "canonical_ee_quat_base_wxyz",
    "dls_lambda",
    "singular_value_threshold",
    "singularity_dls_lambda",
    "max_joint_step_rad",
    "joint_step_gain",
    "minimum_joint_limit_margin_rad",
    "pose_error_weights",
    "posture_joint_targets_rad",
    "posture_gain",
    "posture_damping",
    "ready_duration_s",
    "initial_orientation_tolerance_rad",
    "tracking_orientation_tolerance_rad",
    "tracking_position_tolerance_m",
}


def parse_reaching_pose_contract(config: dict[str, Any]) -> ReachingPoseControllerContract:
    """Parse a complete contract and reject missing or unrecognized fields."""
    missing = _CONTRACT_KEYS - set(config)
    extra = set(config) - _CONTRACT_KEYS
    if missing or extra:
        raise ValueError(
            "pose_controller keys do not match the strict contract: "
            f"missing={sorted(missing)}, extra={sorted(extra)}."
        )
    quaternion = tuple(float(value) for value in config["canonical_ee_quat_base_wxyz"])
    weights = tuple(float(value) for value in config["pose_error_weights"])
    posture_config = config["posture_joint_targets_rad"]
    if not isinstance(posture_config, dict):
        raise ValueError("posture_joint_targets_rad must be a mapping of joint names to radians.")
    posture_targets = tuple((str(name), float(value)) for name, value in posture_config.items())
    if len(quaternion) != 4:
        raise ValueError("canonical_ee_quat_base_wxyz must contain four values.")
    if len(weights) != 6:
        raise ValueError("pose_error_weights must contain six values.")
    return ReachingPoseControllerContract(
        version=str(config["version"]),
        canonical_ee_quat_base_wxyz=quaternion,
        dls_lambda=float(config["dls_lambda"]),
        singular_value_threshold=float(config["singular_value_threshold"]),
        singularity_dls_lambda=float(config["singularity_dls_lambda"]),
        max_joint_step_rad=float(config["max_joint_step_rad"]),
        joint_step_gain=float(config["joint_step_gain"]),
        minimum_joint_limit_margin_rad=float(config["minimum_joint_limit_margin_rad"]),
        pose_error_weights=weights,
        posture_joint_targets_rad=posture_targets,
        posture_gain=float(config["posture_gain"]),
        posture_damping=float(config["posture_damping"]),
        ready_duration_s=float(config["ready_duration_s"]),
        initial_orientation_tolerance_rad=float(config["initial_orientation_tolerance_rad"]),
        tracking_orientation_tolerance_rad=float(config["tracking_orientation_tolerance_rad"]),
        tracking_position_tolerance_m=float(config["tracking_position_tolerance_m"]),
    )


def create_reaching_ik_controllers(
    contract: ReachingPoseControllerContract,
) -> tuple[object, object]:
    """Create reset and execution controllers shared by collection and inference."""
    from franka_wrist_camera_scene.control.ik import CartesianIKController

    ready_controller = CartesianIKController(
        command_type="pose",
        pose_error_weights=contract.pose_error_weights,
        dls_lambda=contract.dls_lambda,
        singular_value_threshold=contract.singular_value_threshold,
        singularity_dls_lambda=contract.singularity_dls_lambda,
        max_joint_step_rad=contract.max_joint_step_rad,
        joint_step_gain=contract.joint_step_gain,
    )
    execution_controller = CartesianIKController(
        command_type="pose",
        pose_error_weights=contract.pose_error_weights,
        dls_lambda=contract.dls_lambda,
        singular_value_threshold=contract.singular_value_threshold,
        singularity_dls_lambda=contract.singularity_dls_lambda,
        max_joint_step_rad=contract.max_joint_step_rad,
        joint_step_gain=contract.joint_step_gain,
    )
    return ready_controller, execution_controller


def canonical_quaternion_world_xyzw(
    robot_root_quat_world_xyzw: torch.Tensor,
    contract: ReachingPoseControllerContract,
) -> torch.Tensor:
    """Compose the configured robot-base canonical orientation into world XYZW."""
    from isaaclab.utils.math import quat_mul

    if robot_root_quat_world_xyzw.ndim != 2 or robot_root_quat_world_xyzw.shape[1] != 4:
        raise ValueError(
            "robot_root_quat_world_xyzw must have shape [N, 4], got "
            f"{tuple(robot_root_quat_world_xyzw.shape)}."
        )
    if not torch.isfinite(robot_root_quat_world_xyzw).all():
        raise ValueError("robot_root_quat_world_xyzw contains NaN or Inf.")
    canonical_wxyz = torch.tensor(
        contract.canonical_ee_quat_base_wxyz,
        device=robot_root_quat_world_xyzw.device,
        dtype=robot_root_quat_world_xyzw.dtype,
    ).view(1, 4)
    canonical_xyzw = torch.cat((canonical_wxyz[:, 1:], canonical_wxyz[:, :1]), dim=-1)
    return quat_mul(robot_root_quat_world_xyzw, canonical_xyzw.expand_as(robot_root_quat_world_xyzw))


def configured_posture_bias(contract: ReachingPoseControllerContract) -> object | None:
    """Build the explicit null-space posture preference from the contract."""
    from franka_wrist_camera_scene.control.ik import PostureBiasCfg

    if contract.posture_gain == 0.0:
        return None
    return PostureBiasCfg(
        joint_pos=dict(contract.posture_joint_targets_rad),
        gain=contract.posture_gain,
        damping=contract.posture_damping,
    )


def quaternion_angular_error_rad_xyzw(
    actual_xyzw: torch.Tensor,
    target_xyzw: torch.Tensor,
) -> torch.Tensor:
    """Return sign-invariant quaternion angular distance in radians."""
    if actual_xyzw.shape != target_xyzw.shape or actual_xyzw.shape[-1] != 4:
        raise ValueError(
            "Quaternion arrays must have matching [..., 4] shapes, got "
            f"{tuple(actual_xyzw.shape)} and {tuple(target_xyzw.shape)}."
        )
    actual = actual_xyzw / torch.linalg.vector_norm(actual_xyzw, dim=-1, keepdim=True)
    target = target_xyzw / torch.linalg.vector_norm(target_xyzw, dim=-1, keepdim=True)
    dot = torch.sum(actual * target, dim=-1).abs().clamp(max=1.0)
    return 2.0 * torch.acos(dot)


def pose_tracking_errors_world_xyzw(
    actual_position_world: torch.Tensor,
    actual_quaternion_world_xyzw: torch.Tensor,
    target_position_world: torch.Tensor,
    target_quaternion_world_xyzw: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return per-environment Cartesian position and orientation tracking errors."""
    if actual_position_world.shape != target_position_world.shape:
        raise ValueError(
            "Position arrays must have matching shapes, got "
            f"{tuple(actual_position_world.shape)} and {tuple(target_position_world.shape)}."
        )
    if actual_position_world.ndim != 2 or actual_position_world.shape[1] != 3:
        raise ValueError(
            "Position arrays must have shape [N, 3], got "
            f"{tuple(actual_position_world.shape)}."
        )
    tensors = {
        "actual_position_world": actual_position_world,
        "actual_quaternion_world_xyzw": actual_quaternion_world_xyzw,
        "target_position_world": target_position_world,
        "target_quaternion_world_xyzw": target_quaternion_world_xyzw,
    }
    non_finite = [name for name, value in tensors.items() if not torch.isfinite(value).all()]
    if non_finite:
        raise ValueError(f"Pose tracking arrays contain NaN or Inf: {non_finite}.")
    position_error = torch.linalg.vector_norm(
        actual_position_world - target_position_world,
        dim=-1,
    )
    orientation_error = quaternion_angular_error_rad_xyzw(
        actual_quaternion_world_xyzw,
        target_quaternion_world_xyzw,
    )
    return position_error, orientation_error


def canonical_quaternion_base_wxyz_from_world(
    quaternion_world_xyzw: torch.Tensor,
    robot_root_quat_world_xyzw: torch.Tensor,
) -> torch.Tensor:
    """Convert an observed world XYZW quaternion to explicit robot-base WXYZ."""
    from isaaclab.utils.math import quat_inv, quat_mul

    quaternion_base_xyzw = quat_mul(quat_inv(robot_root_quat_world_xyzw), quaternion_world_xyzw)
    return quat_xyzw_to_wxyz_torch(quaternion_base_xyzw)
