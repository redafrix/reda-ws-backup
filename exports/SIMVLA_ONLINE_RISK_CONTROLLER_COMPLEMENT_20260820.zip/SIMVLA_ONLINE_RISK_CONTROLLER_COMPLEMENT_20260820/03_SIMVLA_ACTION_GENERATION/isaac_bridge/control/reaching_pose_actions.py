"""Pure action encoding for the strict reaching pose controller contract."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.spatial.transform import Rotation


@dataclass(frozen=True, slots=True)
class RobotBaseFrame:
    position_w: np.ndarray
    quaternion_wxyz: np.ndarray


@dataclass(frozen=True, slots=True)
class PoseCommandAnchor:
    position_w: np.ndarray
    quaternion_xyzw: np.ndarray


@dataclass(frozen=True, slots=True)
class PoseCommandSequence:
    measured_position_w: np.ndarray
    measured_quaternion_xyzw: np.ndarray
    command_position_w: np.ndarray
    command_quaternion_xyzw: np.ndarray
    finger_opening_m: np.ndarray


@dataclass(frozen=True, slots=True)
class DecodedPoseCommand:
    anchor: PoseCommandAnchor
    finger_opening_m: float


def _finite_array(name: str, value: np.ndarray, shape: tuple[int | None, ...]) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.ndim != len(shape) or any(
        expected is not None and actual != expected
        for actual, expected in zip(array.shape, shape, strict=True)
    ):
        raise ValueError(f"{name} must have shape {shape}, got {array.shape}.")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains NaN or Inf.")
    return array


def _normalized_quaternions(name: str, value: np.ndarray) -> np.ndarray:
    quaternions = _finite_array(name, value, (None, 4))
    norms = np.linalg.norm(quaternions, axis=1, keepdims=True)
    if np.any(norms <= 1.0e-8):
        raise ValueError(f"{name} contains a near-zero quaternion.")
    return quaternions / norms


def _base_rotation(base_frame: RobotBaseFrame) -> Rotation:
    quaternion_wxyz = _finite_array(
        "robot_base_quaternion_wxyz",
        base_frame.quaternion_wxyz,
        (4,),
    )
    norm = float(np.linalg.norm(quaternion_wxyz))
    if norm <= 1.0e-8:
        raise ValueError("robot_base_quaternion_wxyz has a near-zero norm.")
    normalized = quaternion_wxyz / norm
    quaternion_xyzw = np.concatenate((normalized[1:], normalized[:1]))
    return Rotation.from_quat(quaternion_xyzw)


def encode_command_increment_sequence(
    sequence: PoseCommandSequence,
    base_frame: RobotBaseFrame,
) -> np.ndarray:
    """Encode same-tick persistent command increments in the robot-base frame."""
    measured_position = _finite_array(
        "measured_position_w", sequence.measured_position_w, (None, 3)
    )
    measured_quaternion = _normalized_quaternions(
        "measured_quaternion_xyzw", sequence.measured_quaternion_xyzw
    )
    command_position = _finite_array(
        "command_position_w", sequence.command_position_w, (None, 3)
    )
    command_quaternion = _normalized_quaternions(
        "command_quaternion_xyzw", sequence.command_quaternion_xyzw
    )
    finger_opening = _finite_array(
        "finger_opening_m", sequence.finger_opening_m, (None,)
    )
    lengths = {
        len(measured_position),
        len(measured_quaternion),
        len(command_position),
        len(command_quaternion),
        len(finger_opening),
    }
    if len(lengths) != 1 or not lengths or next(iter(lengths)) == 0:
        raise ValueError(f"Pose command arrays must share one positive length, got {lengths}.")

    base_rotation = _base_rotation(base_frame)
    anchor_positions = np.concatenate((measured_position[:1], command_position[:-1]), axis=0)
    anchor_quaternions = np.concatenate(
        (measured_quaternion[:1], command_quaternion[:-1]), axis=0
    )
    anchor_rotations_base = base_rotation.inv() * Rotation.from_quat(anchor_quaternions)
    command_rotations_base = base_rotation.inv() * Rotation.from_quat(command_quaternion)

    actions = np.empty((len(command_position), 7), dtype=np.float32)
    actions[:, :3] = base_rotation.inv().apply(
        command_position - anchor_positions
    ).astype(np.float32)
    actions[:, 3:6] = (
        command_rotations_base * anchor_rotations_base.inv()
    ).as_rotvec().astype(np.float32)
    actions[:, 6] = np.where(finger_opening <= 0.02, 1.0, -1.0).astype(np.float32)
    return actions


def decode_command_increment(
    action: np.ndarray,
    anchor: PoseCommandAnchor,
    base_frame: RobotBaseFrame,
) -> DecodedPoseCommand:
    """Integrate one robot-base increment into the persistent pose command."""
    action_array = _finite_array("action", action, (7,))
    anchor_position = _finite_array("anchor_position_w", anchor.position_w, (3,))
    anchor_quaternion = _finite_array(
        "anchor_quaternion_xyzw", anchor.quaternion_xyzw, (4,)
    )
    anchor_norm = float(np.linalg.norm(anchor_quaternion))
    if anchor_norm <= 1.0e-8:
        raise ValueError("anchor_quaternion_xyzw has a near-zero norm.")

    base_rotation = _base_rotation(base_frame)
    anchor_rotation_base = base_rotation.inv() * Rotation.from_quat(anchor_quaternion / anchor_norm)
    command_rotation_base = Rotation.from_rotvec(action_array[3:6]) * anchor_rotation_base
    command_rotation_w = base_rotation * command_rotation_base
    command_position_w = anchor_position + base_rotation.apply(action_array[:3])
    finger_opening_m = 0.0 if float(action_array[6]) >= 0.0 else 0.04
    return DecodedPoseCommand(
        anchor=PoseCommandAnchor(
            position_w=command_position_w.astype(np.float64),
            quaternion_xyzw=command_rotation_w.as_quat().astype(np.float64),
        ),
        finger_opening_m=finger_opening_m,
    )
