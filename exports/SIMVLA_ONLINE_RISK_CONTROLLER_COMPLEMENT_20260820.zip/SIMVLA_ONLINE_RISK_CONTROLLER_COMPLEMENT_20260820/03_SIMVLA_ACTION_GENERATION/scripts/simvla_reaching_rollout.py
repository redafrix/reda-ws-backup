#!/usr/bin/env python3
"""Closed-loop SimVLA reaching rollout in the IsaacLab tabletop scene."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import traceback

import numpy as np
import torch

REPO_SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(REPO_SRC))

from franka_wrist_camera_scene.app import launcher  # noqa: F401
from isaaclab.app import AppLauncher  # noqa: E402
from franka_wrist_camera_scene.simvla.policy import SimVLAActionPolicy, SimVLALiveObservation  # noqa: E402
from franka_wrist_camera_scene.simvla.runtime import SimVLARuntime  # noqa: E402
from franka_wrist_camera_scene.simvla.geometry import (  # noqa: E402
    quat_wxyz_to_xyzw,
    quat_xyzw_to_wxyz,
)
from franka_wrist_camera_scene.simvla.ood_benchmark import (  # noqa: E402
    BenchmarkEpisode,
    BenchmarkManifest,
    load_benchmark_manifest,
    make_reaching_sampling_options,
    require_scene_matches_manifest,
)
from franka_wrist_camera_scene.simvla.timing import validate_simvla_rollout_timing  # noqa: E402
from franka_wrist_camera_scene.simvla.preflight import (  # noqa: E402
    build_runtime_config,
    validate_collection_contract,
    validate_eval_config,
)
from franka_wrist_camera_scene.utils.paths import load_yaml_config  # noqa: E402
from franka_wrist_camera_scene.utils.quaternion import quat_apply_wxyz  # noqa: E402

FABRIC_RENDER_TRANSFORM_SETTING = "/rtx/hydra/readTransformsFromFabricInRenderDelegate"


@dataclass(frozen=True, slots=True)
class RolloutEpisode:
    output_episode_id: int
    source_episode_id: int
    benchmark_episode: BenchmarkEpisode | None = None


@dataclass(frozen=True, slots=True)
class BenchmarkRunContext:
    manifest: BenchmarkManifest
    episode: BenchmarkEpisode


def summarize_uncertainty_replan(
    uncertainty: dict[str, np.ndarray],
    *,
    control_tick: int,
    simulation_step: int,
) -> dict:
    path_variance = np.asarray(uncertainty["path_variance"], dtype=np.float64)
    last_step_variance = np.asarray(
        uncertainty["last_step_variance"],
        dtype=np.float64,
    )
    expected_shape = (1, 10, 7)
    if path_variance.shape != expected_shape or last_step_variance.shape != expected_shape:
        raise RuntimeError(
            "Uncertainty trace requires path_variance and last_step_variance "
            f"with shape {expected_shape}."
        )
    path = path_variance[0]
    final = last_step_variance[0]
    return {
        "control_tick": int(control_tick),
        "simulation_step": int(simulation_step),
        "path_variance": path.tolist(),
        "last_step_variance": final.tolist(),
        "scores": {
            "path_all_sum": float(path.sum()),
            "path_translation_sum": float(path[:, :3].sum()),
            "path_rotation_sum": float(path[:, 3:6].sum()),
            "path_gripper_sum": float(path[:, 6].sum()),
            "final_all_mean": float(final.mean()),
            "final_translation_mean": float(final[:, :3].mean()),
            "final_rotation_mean": float(final[:, 3:6].mean()),
            "final_gripper_mean": float(final[:, 6].mean()),
        },
    }


def _append_kit_arg(existing: str, *tokens: str) -> str:
    parts = existing.split() if existing else []
    parts.extend(tokens)
    return " ".join(parts)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run closed-loop SimVLA reaching rollouts.")
    parser.add_argument("--rollout_config", type=Path, default=Path("configs/eval_simvla_reaching_10_gui.yaml"))
    parser.add_argument("--benchmark-offset", type=int, default=0)
    parser.add_argument("--benchmark-count", type=int)
    parser.add_argument("--allow_fabric_render_transforms", action="store_true")
    AppLauncher.add_app_launcher_args(parser)
    args = parser.parse_args()
    args.enable_cameras = True
    if not args.allow_fabric_render_transforms:
        args.kit_args = _append_kit_arg(args.kit_args, f"--{FABRIC_RENDER_TRANSFORM_SETTING}=false")
    return args


def import_isaac_runtime_modules() -> None:
    """Import Isaac/PXR-touching modules after SimulationApp exists."""
    global sim_utils, Articulation, InteractiveScene
    global make_simulation_cfg, collection_configs_from_config
    global _apply_camera_resolution, _build_asset_bank, _configured_camera_resolution, _configured_camera_resolutions
    global _episode_asset_names
    global _inactive_reaching_asset_names, _make_episode_plan, _make_reaching_recorder
    global _sample_all_scene_assets, validate_reaching_plan
    global move_robot_to_raised_ready_pose
    global GripperController, reset_reaching_episode, reaching_success_metrics
    global wait_for_pending_episode_writes
    global canonical_quaternion_world_xyzw, create_shared_reaching_ik_controllers
    global configured_posture_bias, parse_reaching_pose_contract, require_canonical_initial_orientation
    global suite_metadata_from_config, PolicyCommand, set_dome_light, make_reaching_asset_bank_scene_cfg
    global ReachingTaskSpec, ReachingSamplingOptions, as_torch

    import isaaclab.sim as sim_utils
    from isaaclab.assets import Articulation
    from isaaclab.scene import InteractiveScene

    from franka_wrist_camera_scene.app.simulation_config import make_simulation_cfg
    from franka_wrist_camera_scene.collection.configs import collection_configs_from_config
    from franka_wrist_camera_scene.collection.ready_pose import move_robot_to_raised_ready_pose
    from franka_wrist_camera_scene.collection.reaching import (
        _apply_camera_resolution,
        _build_asset_bank,
        _configured_camera_resolution,
        _configured_camera_resolutions,
        _episode_asset_names,
        _inactive_reaching_asset_names,
        _make_episode_plan,
        _make_reaching_recorder,
        _sample_all_scene_assets,
        validate_reaching_plan,
    )
    from franka_wrist_camera_scene.control.gripper import GripperController
    from franka_wrist_camera_scene.control.reaching_pose import (
        canonical_quaternion_world_xyzw,
        create_reaching_ik_controllers as create_shared_reaching_ik_controllers,
        configured_posture_bias,
        parse_reaching_pose_contract,
    )
    from franka_wrist_camera_scene.collection.reaching import (
        _require_canonical_initial_orientation as require_canonical_initial_orientation,
    )
    from franka_wrist_camera_scene.episode.reset import reset_reaching_episode
    from franka_wrist_camera_scene.episode.recorder import wait_for_pending_episode_writes
    from franka_wrist_camera_scene.episode.success import reaching_success_metrics
    from franka_wrist_camera_scene.episode.suite import suite_metadata_from_config
    from franka_wrist_camera_scene.policies.scripted_base import PolicyCommand
    from franka_wrist_camera_scene.scene.lighting import set_dome_light
    from franka_wrist_camera_scene.scene.tabletop import make_reaching_asset_bank_scene_cfg
    from franka_wrist_camera_scene.tasks.reaching import ReachingTaskSpec
    from franka_wrist_camera_scene.tasks.sampling import ReachingSamplingOptions
    from franka_wrist_camera_scene.utils.tensors import as_torch


def rollout_collection_config(rollout_cfg: dict) -> dict:
    if "collection_index" not in rollout_cfg:
        raise ValueError("SimVLA reaching rollout requires an explicit collection_index.")
    if "expected_split" not in rollout_cfg:
        raise ValueError("SimVLA reaching rollout requires an explicit expected_split.")
    collection_configs = collection_configs_from_config(
        load_yaml_config(rollout_cfg["collection_config"])
    )
    collection_index = int(rollout_cfg["collection_index"])
    if not 0 <= collection_index < len(collection_configs):
        raise IndexError(
            f"collection_index={collection_index} is outside "
            f"{len(collection_configs)} configs."
        )
    collection_cfg = collection_configs[collection_index]
    if collection_cfg.get("task") != "reaching":
        raise ValueError(f"Reaching rollout requires task='reaching', got {collection_cfg.get('task')!r}.")
    expected_split = str(rollout_cfg["expected_split"])
    actual_split = str(collection_cfg.get("suite", {}).get("split"))
    if actual_split != expected_split:
        raise ValueError(
            f"Reaching rollout selected suite split {actual_split!r}, "
            f"expected {expected_split!r}."
        )
    if not bool(rollout_cfg.get("simvla", {}).get("stop_on_success", True)):
        raise ValueError("SimVLA reaching rollout currently requires simvla.stop_on_success=true.")
    if "policy_sampling_seed" not in rollout_cfg:
        raise ValueError(
            "SimVLA reaching rollout requires an explicit policy_sampling_seed."
        )
    for key in (
        "output_dir",
        "start_episode_id",
        "num_episodes",
        "num_envs",
        "max_steps",
        "success_threshold_m",
        "counterfactual_success_threshold_m",
        "settle_time_s",
        "record_cameras",
        "record_depth",
        "save_training_rgb_arrays",
        "save_rgb_videos",
        "camera_fps",
        "state_record_fps",
        "control_fps",
        "control_decimation",
        "use_fabric",
        "policy_sampling_seed",
    ):
        if key in rollout_cfg:
            collection_cfg[key] = rollout_cfg[key]
    if int(collection_cfg.get("num_envs", 1)) != 1:
        raise ValueError("SimVLA GUI rollout currently requires num_envs=1.")
    if not bool(collection_cfg.get("record_cameras", False)):
        raise ValueError("SimVLA reaching rollout requires record_cameras=true.")
    return collection_cfg


def make_sampling_options(collection_cfg: dict) -> tuple[ReachingTaskSpec, ReachingSamplingOptions]:
    return make_reaching_sampling_options(collection_cfg)


def camera_rgb(scene: InteractiveScene, camera_name: str) -> np.ndarray:
    rgb = scene[camera_name].data.output["rgb"][0].detach().cpu().numpy()[..., :3]
    return np.clip(rgb, 0, 255).astype(np.uint8).copy()


def make_live_observation(
    scene: InteractiveScene,
    robot: Articulation,
    ee_body_id: int,
    instruction: str,
) -> SimVLALiveObservation:
    ee_pose = as_torch(robot.data.body_pose_w)[0, ee_body_id]
    robot_base_pose = as_torch(robot.data.root_pose_w)[0]
    joint_pos = as_torch(robot.data.joint_pos)[0]
    if joint_pos.numel() < 9:
        raise RuntimeError(f"Expected Franka arm plus two finger joints, got {tuple(joint_pos.shape)}.")
    fingers = joint_pos[7:9]
    if not bool(torch.isfinite(fingers).all().item()):
        raise RuntimeError(f"Finger joint positions contain non-finite values: {fingers.detach().cpu().tolist()}")
    measured_opening_m = max(0.0, float(torch.mean(fingers).item()))
    if measured_opening_m > 0.08:
        raise RuntimeError(f"Measured finger opening {measured_opening_m:.6f}m is outside expected Franka range.")
    return SimVLALiveObservation(
        language_instruction=instruction,
        agent_rgb=camera_rgb(scene, "agent_camera"),
        wrist_rgb=camera_rgb(scene, "wrist_camera"),
        ee_pos_w=ee_pose[:3].detach().cpu().numpy(),
        ee_quat_wxyz=quat_xyzw_to_wxyz(ee_pose[3:7].detach().cpu().numpy()),
        robot_base_pos_w=robot_base_pose[:3].detach().cpu().numpy(),
        robot_base_quat_wxyz=quat_xyzw_to_wxyz(
            robot_base_pose[3:7].detach().cpu().numpy()
        ),
        finger_opening_m=measured_opening_m,
    )


def target_reach_pos_w(scene: InteractiveScene, spec: ReachingTaskSpec) -> torch.Tensor:
    obj = scene[spec.object_name]
    obj_pos_w = as_torch(obj.data.root_pos_w)[:, :3]
    reach_offset = torch.tensor(spec.object_reach_offset_local, device=obj_pos_w.device).view(1, 3)
    return obj_pos_w + reach_offset


def run_simvla_reaching_episode(
    *,
    sim: sim_utils.SimulationContext,
    scene: InteractiveScene,
    robot: Articulation,
    ready_ik: CartesianIKController,
    ik: CartesianIKController,
    gripper: GripperController,
    simvla_policy: SimVLAActionPolicy,
    collection_cfg: dict,
    episode_id: int,
    episode_plan,
    scene_assets,
    asset_bank,
    output_dir: Path,
    simulation_app,
    suite,
    seed: int,
    eval_cfg: dict,
    benchmark_context: BenchmarkRunContext | None = None,
) -> Path:
    asset_names = _episode_asset_names(asset_bank, scene_assets)
    inactive_object_names, inactive_clutter_names = _inactive_reaching_asset_names(asset_bank, asset_names)
    reset_reaching_episode(
        sim=sim,
        scene=scene,
        spec=episode_plan.spec,
        clutter_specs=episode_plan.clutter_specs,
        inactive_object_names=inactive_object_names,
        inactive_clutter_names=inactive_clutter_names,
        reset_scene=False,
    )
    set_dome_light(scene, episode_plan.sample.light_intensity, episode_plan.sample.light_color)
    pose_contract = parse_reaching_pose_contract(collection_cfg["pose_controller"])
    canonical_quat_world_xyzw = canonical_quaternion_world_xyzw(
        as_torch(robot.data.root_pose_w)[:, 3:7],
        pose_contract,
    )
    ready_ik.reset()
    shared_posture_bias = configured_posture_bias(pose_contract)
    ready_ik.set_posture_bias(shared_posture_bias)
    move_robot_to_raised_ready_pose(
        sim=sim,
        scene=scene,
        robot=robot,
        ik=ready_ik,
        gripper=gripper,
        ee_body_id=ready_ik.end_effector_body_id,
        height_offset_m=float(collection_cfg["robot_ready_height_offset_m"]),
        finger_opening_m=episode_plan.spec.closed_finger_m,
        duration_s=pose_contract.ready_duration_s,
        target_quat_world_xyzw=canonical_quat_world_xyzw,
    )
    if not simulation_app.is_running():
        raise RuntimeError("Isaac Sim stopped during reaching ready-pose initialization.")
    require_canonical_initial_orientation(
        robot,
        ik.end_effector_body_id,
        canonical_quat_world_xyzw,
        pose_contract,
    )
    policy_sampling_seed = int(collection_cfg["policy_sampling_seed"]) + episode_id
    simvla_policy.reset(sampling_seed=policy_sampling_seed)
    ik.reset()
    ik.set_posture_bias(shared_posture_bias)

    sim_dt = sim.get_physics_dt()
    timing = validate_simvla_rollout_timing(collection_cfg, sim_dt)
    recorder = _make_reaching_recorder(
        output_dir=output_dir,
        episode_id=episode_id,
        plan=episode_plan,
        scene_assets=scene_assets,
        sim_dt=sim_dt,
        ee_body_id=ik.end_effector_body_id,
        max_steps=int(collection_cfg["max_steps"]),
        record_cameras=bool(collection_cfg["record_cameras"]),
        record_depth=bool(collection_cfg["record_depth"]),
        save_rgb_videos=bool(collection_cfg.get("save_rgb_videos", False)),
        camera_width=int(collection_cfg["camera_width"]),
        camera_height=int(collection_cfg["camera_height"]),
        agent_camera_width=int(collection_cfg["agent_camera_width"]),
        agent_camera_height=int(collection_cfg["agent_camera_height"]),
        wrist_camera_width=int(collection_cfg["wrist_camera_width"]),
        wrist_camera_height=int(collection_cfg["wrist_camera_height"]),
        camera_fps=int(collection_cfg["camera_fps"]),
        state_record_stride=timing.state_record_stride,
        control_decimation=timing.control_decimation,
        control_fps=timing.control_fps,
        suite=suite,
        seed=seed,
        env_index=None,
        pose_contract=pose_contract,
        collection_num_envs=scene.num_envs,
    )
    recorder.save_training_rgb_arrays = bool(
        collection_cfg.get("save_training_rgb_arrays", True)
    )
    recorder.validate_output_path()

    latched_reach_pos_w = target_reach_pos_w(scene, episode_plan.spec).detach().clone()
    sim_time_s = 0.0
    step = 0
    control_tick_index = 0
    settle_steps = 0
    max_settle_steps = int(float(collection_cfg["settle_time_s"]) / sim_dt)
    counterfactual_threshold_m = collection_cfg.get(
        "counterfactual_success_threshold_m"
    )
    if counterfactual_threshold_m is not None:
        counterfactual_threshold_m = float(counterfactual_threshold_m)
        if counterfactual_threshold_m <= episode_plan.spec.success_threshold_m:
            raise ValueError(
                "counterfactual_success_threshold_m must exceed the online "
                f"success threshold, got {counterfactual_threshold_m}."
            )
    counterfactual_settle_steps = 0
    counterfactual_completed = False
    counterfactual_completed_step: int | None = None
    minimum_latched_distance_m = float("inf")
    minimum_live_distance_m = float("inf")
    current_cmd: PolicyCommand | None = None
    completed = False
    completed_step: int | None = None
    uncertainty_trace: list[dict] = []

    while simulation_app.is_running() and step < int(collection_cfg["max_steps"]):
        if step % timing.camera_interval_steps == 0:
            scene["agent_camera"].update(sim_dt, force_recompute=True)
            scene["wrist_camera"].update(sim_dt, force_recompute=True)

        control_tick = step % timing.control_decimation == 0
        if control_tick:
            obs = make_live_observation(
                scene=scene,
                robot=robot,
                ee_body_id=ik.end_effector_body_id,
                instruction=episode_plan.spec.instruction,
            )
            current_cmd = simvla_policy.step(obs, camera_tick=control_tick_index)
            if (
                simvla_policy.last_step_replanned
                and eval_cfg["simvla"]["predict_uncertainty"]
            ):
                uncertainty_trace.append(
                    summarize_uncertainty_replan(
                        simvla_policy.last_uncertainty,
                        control_tick=control_tick_index,
                        simulation_step=step,
                    )
                )
            control_tick_index += 1

        if current_cmd is None:
            raise RuntimeError("SimVLA policy did not produce a pose command.")

        target_quat_xyzw = torch.as_tensor(
            quat_wxyz_to_xyzw(
                current_cmd.target_quat_w.detach().cpu().numpy()
                if isinstance(current_cmd.target_quat_w, torch.Tensor)
                else current_cmd.target_quat_w
            ),
            device=robot.device,
            dtype=torch.float32,
        )
        ik.set_target_pose(current_cmd.target_pos_w, target_quat_xyzw)
        ik.apply(scene, robot)
        gripper.set_width(current_cmd.finger_opening_m)
        gripper.apply(robot)
        scene.write_data_to_sim()
        if control_tick:
            recorder.record_step(scene, current_cmd, step, sim_time_s)
        if bool(collection_cfg["record_cameras"]) and step % timing.camera_interval_steps == 0:
            recorder.record_cameras_step(scene, step, sim_time_s, refresh=False)

        sim.step()
        sim_time_s += sim_dt
        step += 1
        scene.update(sim_dt)

        metrics = reaching_success_metrics(
            scene=scene,
            spec=episode_plan.spec,
            target_reach_pos_w=latched_reach_pos_w,
        )
        minimum_latched_distance_m = min(
            minimum_latched_distance_m,
            float(metrics.latched_distance_m[0].item()),
        )
        minimum_live_distance_m = min(
            minimum_live_distance_m,
            float(metrics.live_distance_m[0].item()),
        )
        if counterfactual_threshold_m is not None and not counterfactual_completed:
            counterfactual_metrics = reaching_success_metrics(
                scene=scene,
                spec=episode_plan.spec,
                target_reach_pos_w=latched_reach_pos_w,
                threshold_m=counterfactual_threshold_m,
            )
            if bool(counterfactual_metrics.success[0].item()):
                counterfactual_settle_steps += 1
                if counterfactual_settle_steps >= max_settle_steps:
                    counterfactual_completed = True
                    counterfactual_completed_step = step
            else:
                counterfactual_settle_steps = 0
        if bool(metrics.success[0].item()):
            settle_steps += 1
            if settle_steps >= max_settle_steps:
                completed = True
                completed_step = step
                break
        else:
            settle_steps = 0

    metrics = reaching_success_metrics(
        scene=scene,
        spec=episode_plan.spec,
        target_reach_pos_w=latched_reach_pos_w,
    )
    minimum_latched_distance_m = min(
        minimum_latched_distance_m,
        float(metrics.latched_distance_m[0].item()),
    )
    minimum_live_distance_m = min(
        minimum_live_distance_m,
        float(metrics.live_distance_m[0].item()),
    )
    success = completed
    success_mode = "failure"
    if success and bool(metrics.reached_latched_target[0].item()):
        success_mode = "latched_target"
    elif success and bool(
        (metrics.reached_live_target & metrics.target_displacement_ok)[0].item()
    ):
        success_mode = "live_target_with_small_displacement"

    saved_dir = recorder.save(success, success_mode=success_mode)
    if eval_cfg["simvla"]["predict_uncertainty"]:
        if not uncertainty_trace:
            raise RuntimeError("Uncertainty-enabled rollout produced no replan trace.")
        trace_payload = {
            "schema_version": "simvla_reaching_uncertainty_trace_v1",
            "uncertainty_parameterization": eval_cfg["simvla"][
                "uncertainty_parameterization"
            ],
            "checkpoint_path": str(eval_cfg["simvla"]["checkpoint_path"]),
            "checkpoint_model_sha256": eval_cfg["simvla"][
                "checkpoint_model_sha256"
            ],
            "policy_sampling_seed": policy_sampling_seed,
            "inference_steps": int(eval_cfg["simvla"]["inference_steps"]),
            "replan_steps": int(eval_cfg["simvla"]["replan_steps"]),
            "path_variance_semantics": (
                "sum_dt_squared_times_predicted_flow_variance_without_"
                "jacobian_or_cross_step_covariance"
            ),
            "replans": uncertainty_trace,
        }
        (saved_dir / "uncertainty_trace.json").write_text(
            json.dumps(trace_payload, indent=2) + "\n",
            encoding="utf-8",
        )
    if benchmark_context is not None:
        early_replans = uncertainty_trace[:5]
        benchmark_metrics = {
            "schema_version": "simvla_reaching_ood_benchmark_metrics_v1",
            "benchmark_name": benchmark_context.manifest.benchmark_name,
            "manifest_fingerprint_sha256": (
                benchmark_context.manifest.manifest_fingerprint_sha256
            ),
            "scene_fingerprint_sha256": (
                benchmark_context.episode.scene_fingerprint_sha256
            ),
            "benchmark_episode_id": episode_id,
            "source_episode_id": benchmark_context.episode.source_episode_id,
            "strict_success": success,
            "strict_success_threshold_m": episode_plan.spec.success_threshold_m,
            "strict_completed_step": completed_step,
            "counterfactual_success": counterfactual_completed,
            "counterfactual_success_threshold_m": counterfactual_threshold_m,
            "counterfactual_completed_step": counterfactual_completed_step,
            "settle_time_s": float(collection_cfg["settle_time_s"]),
            "minimum_tcp_distance_to_latched_target_m": minimum_latched_distance_m,
            "minimum_tcp_distance_to_live_target_m": minimum_live_distance_m,
            "final_tcp_distance_to_latched_target_m": float(
                metrics.latched_distance_m[0].item()
            ),
            "final_tcp_distance_to_live_target_m": float(
                metrics.live_distance_m[0].item()
            ),
            "target_displacement_m": float(metrics.target_displacement_m[0].item()),
            "simulation_steps": step,
            "control_ticks": control_tick_index,
            "uncertainty_replans": len(uncertainty_trace),
            "uncertainty_early_5_path_translation_mean": (
                float(
                    np.mean(
                        [
                            replan["scores"]["path_translation_sum"]
                            for replan in early_replans
                        ]
                    )
                )
                if early_replans
                else None
            ),
            "uncertainty_full_path_all_mean": (
                float(
                    np.mean(
                        [
                            replan["scores"]["path_all_sum"]
                            for replan in uncertainty_trace
                        ]
                    )
                )
                if uncertainty_trace
                else None
            ),
        }
        (saved_dir / "benchmark_metrics.json").write_text(
            json.dumps(benchmark_metrics, indent=2) + "\n",
            encoding="utf-8",
        )
    print(
        f"[INFO] SimVLA episode {episode_id} success={success} mode={success_mode} "
        f"counterfactual_success={counterfactual_completed} steps={step} "
        f"instruction={episode_plan.spec.instruction!r}",
        flush=True,
    )
    if not success:
        write_failure_json(saved_dir, episode_id, episode_plan, scene, robot, ik.end_effector_body_id, metrics, latched_reach_pos_w, scene_assets)
    return saved_dir


def write_failure_json(
    saved_dir: Path,
    episode_id: int,
    episode_plan,
    scene: InteractiveScene,
    robot: Articulation,
    ee_body_id: int,
    metrics,
    latched_reach_pos_w: torch.Tensor,
    scene_assets,
) -> None:
    ee_pose_w = as_torch(robot.data.body_pose_w)[:, ee_body_id]
    tcp_offset_local = torch.tensor(episode_plan.spec.tcp_offset_local, device=ee_pose_w.device).view(1, 3)
    tcp_pos_w = ee_pose_w[:, :3] + quat_apply_wxyz(
        torch.as_tensor(
            quat_xyzw_to_wxyz(ee_pose_w[:, 3:7].detach().cpu().numpy()),
            device=ee_pose_w.device,
            dtype=ee_pose_w.dtype,
        ),
        tcp_offset_local.expand(ee_pose_w.shape[0], -1),
    )
    obj_pos_w = as_torch(scene[episode_plan.spec.object_name].data.root_pos_w)
    reach_offset = torch.tensor(episode_plan.spec.object_reach_offset_local, device=obj_pos_w.device).view(1, 3)
    failure = {
        "episode_id": episode_id,
        "task_name": "reaching",
        "policy": "simvla",
        "instruction": episode_plan.spec.instruction,
        "object_category_id": scene_assets.object_context.category_id,
        "object_variant_id": scene_assets.object_context.variant_id,
        "object_label": scene_assets.object_context.label,
        "object_final_pos_w": obj_pos_w[0].detach().cpu().tolist(),
        "tcp_final_pos_w": tcp_pos_w[0].detach().cpu().tolist(),
        "latched_target_reach_pos_w": latched_reach_pos_w[0].detach().cpu().tolist(),
        "live_target_reach_pos_w": (obj_pos_w[:, :3] + reach_offset)[0].detach().cpu().tolist(),
        "target_displacement_m": float(metrics.target_displacement_m[0].item()),
        "final_tcp_distance_to_latched_target_m": float(metrics.latched_distance_m[0].item()),
        "final_tcp_distance_to_live_target_m": float(metrics.live_distance_m[0].item()),
        "success_threshold_m": episode_plan.spec.success_threshold_m,
        "max_success_target_displacement_m": episode_plan.spec.max_success_target_displacement_m,
    }
    (saved_dir / "failure.json").write_text(json.dumps(failure, indent=2), encoding="utf-8")


def rollout_episode_selection(
    args: argparse.Namespace,
    rollout_cfg: dict,
    collection_cfg: dict,
) -> tuple[list[RolloutEpisode], BenchmarkManifest | None]:
    manifest_path = rollout_cfg.get("benchmark_manifest")
    if manifest_path is None:
        if args.benchmark_offset != 0 or args.benchmark_count is not None:
            raise ValueError(
                "Benchmark shard arguments require benchmark_manifest in the rollout config."
            )
        start_episode_id = int(collection_cfg["start_episode_id"])
        num_episodes = int(collection_cfg["num_episodes"])
        episodes = [
            RolloutEpisode(
                output_episode_id=episode_id,
                source_episode_id=episode_id,
            )
            for episode_id in range(start_episode_id, start_episode_id + num_episodes)
        ]
        return episodes, None

    manifest = load_benchmark_manifest(Path(manifest_path))
    collection_index = int(rollout_cfg["collection_index"])
    if manifest.collection_index != collection_index:
        raise ValueError(
            f"Manifest collection_index={manifest.collection_index} does not match "
            f"rollout collection_index={collection_index}."
        )
    episodes = [
        RolloutEpisode(
            output_episode_id=entry.benchmark_episode_id,
            source_episode_id=entry.source_episode_id,
            benchmark_episode=entry,
        )
        for entry in manifest.shard(args.benchmark_offset, args.benchmark_count)
    ]
    return episodes, manifest


def run_rollouts(args: argparse.Namespace, simulation_app) -> None:
    rollout_cfg = load_yaml_config(args.rollout_config)
    collection_cfg = rollout_collection_config(rollout_cfg)
    simvla_eval_cfg = load_yaml_config(rollout_cfg["simvla"]["eval_config"])
    validate_eval_config(simvla_eval_cfg)
    validate_collection_contract(collection_cfg, simvla_eval_cfg)
    seed = int(collection_cfg["seed"])
    output_dir = Path(collection_cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    base_spec, sampling_options = make_sampling_options(collection_cfg)
    rollout_episodes, benchmark_manifest = rollout_episode_selection(
        args,
        rollout_cfg,
        collection_cfg,
    )
    source_episode_ids = [episode.source_episode_id for episode in rollout_episodes]
    if len(source_episode_ids) != len(set(source_episode_ids)):
        raise ValueError("Benchmark shard contains duplicate source episode IDs.")
    scene_assets_by_episode = _sample_all_scene_assets(
        collection_cfg,
        seed,
        source_episode_ids,
    )
    asset_bank = _build_asset_bank(scene_assets_by_episode)
    first_id = source_episode_ids[0]
    first_assets = scene_assets_by_episode[first_id]
    first_names = _episode_asset_names(asset_bank, first_assets)
    first_plan = _make_episode_plan(
        collection_cfg, base_spec, first_assets, seed, first_id, sampling_options, first_names
    )
    validate_reaching_plan(collection_cfg, first_assets, first_plan)

    scene_cfg = make_reaching_asset_bank_scene_cfg(
        target_usd_paths=asset_bank.target_usd_paths,
        clutter_usd_paths=asset_bank.clutter_usd_paths,
        initial_target_name=first_names.object_name,
        initial_clutter_names=first_names.clutter_names,
        initial_clutter_specs=first_plan.clutter_specs,
        num_envs=1,
        env_spacing=float(collection_cfg.get("env_spacing", 5.0)),
    )
    camera_width, camera_height = _configured_camera_resolution(collection_cfg)
    agent_camera_width, agent_camera_height, wrist_camera_width, wrist_camera_height = _configured_camera_resolutions(collection_cfg)
    _apply_camera_resolution(
        scene_cfg,
        camera_width,
        camera_height,
        record_depth=bool(collection_cfg["record_depth"]),
        camera_fps=int(collection_cfg["camera_fps"]),
        agent_width=agent_camera_width,
        agent_height=agent_camera_height,
        wrist_width=wrist_camera_width,
        wrist_height=wrist_camera_height,
    )

    runtime = SimVLARuntime(build_runtime_config(simvla_eval_cfg, args.device))
    print("[INFO] Loading SimVLA runtime for closed-loop rollout...", flush=True)
    runtime.load()
    simvla_policy = SimVLAActionPolicy(
        runtime=runtime,
        image_rotation=str(simvla_eval_cfg["simvla"]["image_rotation"]),
        replan_steps=int(simvla_eval_cfg["simvla"]["replan_steps"]),
        command_device=args.device,
    )

    sim = sim_utils.SimulationContext(make_simulation_cfg(args.device, use_fabric=bool(collection_cfg.get("use_fabric", True))))
    scene = InteractiveScene(scene_cfg)
    pose_contract = parse_reaching_pose_contract(collection_cfg["pose_controller"])
    ready_ik, ik = create_shared_reaching_ik_controllers(pose_contract)
    gripper = GripperController()
    sim.reset()
    sim.set_camera_view(eye=[2.2, -2.2, 1.9], target=[0.55, 0.0, 1.20])
    robot = scene["robot"]
    ready_ik.bind(scene, robot)
    ik.bind(scene, robot)
    gripper.bind(scene, robot)
    suite = suite_metadata_from_config(collection_cfg)

    plans = {first_id: first_plan}
    for rollout_episode in rollout_episodes:
        source_episode_id = rollout_episode.source_episode_id
        output_episode_id = rollout_episode.output_episode_id
        assets = scene_assets_by_episode[source_episode_id]
        names = _episode_asset_names(asset_bank, assets)
        plan = plans.get(source_episode_id)
        if plan is None:
            plan = _make_episode_plan(
                collection_cfg,
                base_spec,
                assets,
                seed,
                source_episode_id,
                sampling_options,
                names,
            )
            validate_reaching_plan(collection_cfg, assets, plan)
        benchmark_context = None
        if rollout_episode.benchmark_episode is not None:
            if benchmark_manifest is None:
                raise RuntimeError("Benchmark episode was loaded without its manifest.")
            require_scene_matches_manifest(
                rollout_episode.benchmark_episode,
                assets,
                plan,
            )
            benchmark_context = BenchmarkRunContext(
                manifest=benchmark_manifest,
                episode=rollout_episode.benchmark_episode,
            )
        print(
            f"[INFO] Starting SimVLA reaching episode {output_episode_id}: "
            f"source_episode_id={source_episode_id} "
            f"instruction={plan.spec.instruction!r} "
            f"target={assets.object_context.category_id}/{assets.object_context.variant_id}",
            flush=True,
        )
        run_simvla_reaching_episode(
            sim=sim,
            scene=scene,
            robot=robot,
            ready_ik=ready_ik,
            ik=ik,
            gripper=gripper,
            simvla_policy=simvla_policy,
            collection_cfg=collection_cfg,
            episode_id=output_episode_id,
            episode_plan=plan,
            scene_assets=assets,
            asset_bank=asset_bank,
            output_dir=output_dir,
            simulation_app=simulation_app,
            suite=suite,
            seed=seed,
            eval_cfg=simvla_eval_cfg,
            benchmark_context=benchmark_context,
        )


def main() -> None:
    args = parse_args()
    app_launcher = AppLauncher(args)
    simulation_app = app_launcher.app
    launcher.patch_physx_schema()
    import_isaac_runtime_modules()
    try:
        run_rollouts(args, simulation_app)
    except BaseException:
        traceback.print_exc()
        raise
    finally:
        wait_for_pending_episode_writes()
        simulation_app.close()


if __name__ == "__main__":
    main()
