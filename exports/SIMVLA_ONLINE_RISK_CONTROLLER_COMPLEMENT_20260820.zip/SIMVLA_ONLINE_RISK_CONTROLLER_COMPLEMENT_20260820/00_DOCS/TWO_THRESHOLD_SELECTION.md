# Two-threshold action selection

Let `s[0]` be candidate-0 risk and `s[1:9]` the eight alternative risks.

1. `best_idx = argmin(s[1:]) + 1`
2. If `best >= s[0]`, keep candidate 0.
3. If `s[0] < A`, keep candidate 0. (`A` = main alarm threshold.)
4. If `best > C`, keep candidate 0. (`C` = alternative acceptance cap.)
5. If `s[0] - best < M`, keep candidate 0. (`M=0` deployed.)
6. Otherwise execute `best_idx`.

An intervention therefore requires an alarming main proposal and a strictly lower-risk alternative that is itself below the second threshold.

Historical validated OOD150 controller: `A=0.7990124225616455`, `C=0.90`, `M=0`.

Current OOD400 selected Seen-derived exact value represented in this bundle: `A=0.8792325258255005` (q99-success), `C=0.90`, `M=0`. Do not mix thresholds between experiments; use the experiment-specific frozen controller.
