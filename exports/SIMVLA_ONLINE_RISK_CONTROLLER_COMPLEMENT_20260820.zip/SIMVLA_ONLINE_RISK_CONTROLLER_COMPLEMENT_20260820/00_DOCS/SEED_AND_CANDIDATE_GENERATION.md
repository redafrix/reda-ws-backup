# Seed and candidate generation

## Online TopK action seeds
The current TopK online controller does **not** use one mutable RNG stream for the nine candidates. Each seed is derived from:

`global_seed, source_episode_id, decision_index, candidate_index`

Exact key:

`simvla-isaac-risk-v1|GLOBAL|EPISODE|DECISION|CANDIDATE`

SHA-256 is computed, the first 16 hex digits are converted to an integer, then reduced modulo `2**31 - 1`. Current global policy seed: `20260812`.

For each candidate, `TorchSimVLABackend.sample_one()` creates a dedicated `torch.Generator(device=device)`, calls `manual_seed(seed)`, and draws initial Gaussian latent noise of shape `(1,10,7)`. Every episode/query/candidate therefore has an auditable initial noise sample.

## Flow integration
One VLM encoding is shared by all nine candidates. For each candidate independently: initialize `x_t ~ N(0,I)`; use 10 Euler steps (`dt=-0.1`) from `t=1` to `0`; the action transformer predicts velocity + uncertainty; update `x_t = x_t + dt*velocity`; postprocess the final normalized 10x7 chunk into environment actions.

## Scene randomness is separate
OOD400 was originally generated from fixed benchmark seed `20260812`, but the current evaluator uses **direct manifest reconstruction**. Target/clutter geometry is not resampled from RNG during evaluation.

## Legacy single-candidate behavior
The legacy baseline `SimVLAActionPolicy` used `policy_sampling_seed + episode_id` and `torch.manual_seed(...)` at episode reset. The nine-candidate controller instead uses the hash-per-candidate scheme above.
