# File guide

## Exact online controller
- `01_CURRENT_OOD400_CONTROLLER/ood400_runtime.py`: candidate-specific risk features, risk-head scoring, two-threshold selector, online planner.
- `01_CURRENT_OOD400_CONTROLLER/run_ood400_simvla.py`: full Isaac episode loop, direct manifest reconstruction, H10 execution, 3 cm/350-tick termination, logging.
- `01_CURRENT_OOD400_CONTROLLER/CONTROLLER_CONTRACT_EXACT.json`: compact frozen controller/interface contract.

## Candidate generation and seeds
- `02_SHARED_RISK_COLLECTION/risk_collection/seeds.py`: exact deterministic seed derivation.
- `02_SHARED_RISK_COLLECTION/risk_collection/adapter.py`: one VLM encoding, nine independently seeded flow samples, denoising traces.
- `02_SHARED_RISK_COLLECTION/risk_collection/runtime_policy.py`: original collection planner and history updates.
- `02_SHARED_RISK_COLLECTION/risk_collection/features.py`: 49D uncertainty construction.
- `02_SHARED_RISK_COLLECTION/risk_collection/ace.py`: candidate-disagreement and action statistics.
- `02_SHARED_RISK_COLLECTION/risk_collection/history.py`: 16-query causal history.

## SimVLA action generator, without weights
- `03_SIMVLA_ACTION_GENERATION/simvla_models/`: exact local SimVLA model/action-space/transformer/processor Python implementation.
- `03_SIMVLA_ACTION_GENERATION/isaac_runtime/`: exact Isaac-side runtime, preprocessing, proprio/action integration and benchmark loader.
- `03_SIMVLA_ACTION_GENERATION/scripts/simvla_reaching_rollout.py`: standalone closed-loop rollout reference.
- `03_SIMVLA_ACTION_GENERATION/configs/`: inference and action-normalization contracts.
- `03_SIMVLA_ACTION_GENERATION/checkpoint_metadata/`: checkpoint config/state metadata only; no weights.
## Risk monitor interface
- `04_RISK_MONITOR_INTERFACE/model.py`: temporal risk-model architecture.
- `04_RISK_MONITOR_INTERFACE/common.py`: row/static/history materialization helpers.
- `04_RISK_MONITOR_INTERFACE/current_model_metadata/`: normalization and frozen-threshold metadata; checkpoint weights intentionally omitted.

## Historical validated reference
- `05_HISTORICAL_VALIDATED_OOD150_REFERENCE/`: earlier fully validated online controller/run logic and audited final result artifacts. This is useful as a known-good end-to-end reference for the two-gate replacement mechanism.

## Minimal porting reference
- `06_MINIMAL_REFERENCE/seed_and_selector_reference.py`: dependency-light implementation of the exact seed map and final action-selection rule.