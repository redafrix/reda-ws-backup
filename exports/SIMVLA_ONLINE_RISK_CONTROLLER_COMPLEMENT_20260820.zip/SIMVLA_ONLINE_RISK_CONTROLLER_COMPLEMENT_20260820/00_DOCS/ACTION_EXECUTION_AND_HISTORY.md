# Action execution and temporal history

The selected H10 proposal is postprocessed into ten 7D environment actions: 3 translation deltas, 3 rotation-vector deltas and 1 gripper command. `PersistentPoseCommandIntegrator` accumulates increments into a persistent Cartesian target pose.

Control runs at 30 Hz; physics at 120 Hz (`control_decimation=4`). Production replans only after the current H10 chunk is exhausted. In current OOD400, success is tested after every physics step and terminates immediately at TCP-target distance `<=0.030 m`; a final chunk can therefore be partially executed. Failure occurs at 350 control ticks / 1400 physics steps.

After a decision finishes, one 21D history row is appended: 8D query proprio + the **first actually executed action** (7D) + first 6 values of ACE. History is 16 decisions, left-zero-padded. The current query is excluded from its own history.
