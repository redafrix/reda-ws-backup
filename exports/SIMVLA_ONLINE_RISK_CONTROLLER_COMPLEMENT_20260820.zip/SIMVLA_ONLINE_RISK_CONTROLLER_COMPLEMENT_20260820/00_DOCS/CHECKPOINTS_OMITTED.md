# Checkpoints omitted

This complementary bundle intentionally contains source/configuration logic but not neural-network weights.

Omitted large assets: SimVLA `model.safetensors`, SmolVLM-500M-Instruct, and risk-monitor `model.pt`.

Included metadata records architecture/normalization contracts. The live Dean OOD400 pipeline was actively auditing a SimVLA checkpoint-hash mismatch on 2026-08-20, so this export is a **logic/source reproduction bundle**, not a claim that the currently mounted checkpoint bytes are validated. Use a known-good checkpoint and set its expected hash consistently before execution.
