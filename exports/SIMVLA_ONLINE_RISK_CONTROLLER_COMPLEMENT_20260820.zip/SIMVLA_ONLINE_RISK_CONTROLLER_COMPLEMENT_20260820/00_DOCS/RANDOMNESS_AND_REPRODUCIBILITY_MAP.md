# Randomness and reproducibility map

This file separates the different sources of randomness used by the Isaac/SimVLA evaluation. They are not one shared RNG stream.

## 1. Canonical OOD400 scene generation
The benchmark was generated once with benchmark seed `20260812`. The resulting `full_ood400.json` stores the exact scene identity/layout for all 400 episodes. The current evaluator does **not** resample target/clutter geometry from RNG at runtime; it reconstructs each scene directly from the manifest and checks parity.

## 2. Policy sampling seed
The current OOD400 evaluator freezes `policy_sampling_seed = 20260812`.

## 3. Nine action-candidate seeds per decision
For each policy query, nine independent candidate seeds are derived from four coordinates:

`(global_seed, source_episode_id, decision_index, candidate_index)`

Exact implementation: `02_SHARED_RISK_COLLECTION/risk_collection/seeds.py`.

`key = f"simvla-isaac-risk-v1|{global_seed}|{source_episode_id}|{decision_index}|{candidate_index}"`

`seed = int(sha256(key).hexdigest()[:16], 16) % (2**31 - 1)`

Candidate indices are `0..8`. Candidate 0 is the main SimVLA proposal; 1–8 are alternatives.
## 4. Candidate latent noise
Each candidate uses its own `torch.Generator(device=device)` and `manual_seed(seed)`. The candidate sampler draws initial Gaussian latent action noise of shape `(1,10,7)` with `torch.randn(..., generator=generator)`.

The same visual/language encoding is reused for all nine candidates. Each seeded latent is then integrated independently through 10 Euler flow steps.

## 5. Deterministic Torch runtime settings
`SimVLARuntime.load()` calls `torch.use_deterministic_algorithms(True)`, disables cuDNN benchmarking, and enables deterministic cuDNN mode.

## 6. Legacy single-candidate behavior
The older single-candidate `SimVLAActionPolicy.reset(sampling_seed=...)` used global `torch.manual_seed(sampling_seed)`. That code is retained only as historical/parity reference. The current nine-candidate controller uses the hash-derived per-candidate generators above.

## 7. Scene reset metadata versus policy noise
The OOD400 runner logs `official_scene_sampler_seed`, `scene_reset_seed`, `scene_seed_inputs`, and `policy_sampling_seed`. Scene geometry is fixed by the manifest; policy noise is separately derived at every decision.

## 8. Reproduction rule for Mimic-Video
For a Mimic-Video analogue, preserve the same episode/decision/candidate seed coordinate map if exact bookkeeping is desired. The Mimic-Video branch can map that integer seed to its own native latent-noise generator, but should log the mapping, every candidate seed, and every generated candidate chunk.