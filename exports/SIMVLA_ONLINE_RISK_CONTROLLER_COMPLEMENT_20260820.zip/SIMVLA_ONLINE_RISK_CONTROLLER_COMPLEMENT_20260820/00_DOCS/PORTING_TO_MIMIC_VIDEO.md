# Porting the test to mimic-video

For a fair mimic-video analogue, preserve benchmark/controller semantics while using branch-native uncertainty.

1. Use exact included `full_ood400.json` scenes and same 3cm/350-tick task protocol.
2. At each fresh decision state, generate one main proposal plus eight independently seeded alternatives (one expensive shared context if your architecture allows it).
3. Use the same deterministic seed-coordinate scheme, or document an equivalent deterministic map.
4. Preserve every candidate chunk and seed in logs.
5. Compute candidate-specific branch-native uncertainty and score all nine with the same branch-specific monitor.
6. Apply main alarm `A`, alternative cap `C`, and zero margin unless intentionally changed.
7. Execute the selected proposal with same horizon and success/timeout rules.
8. Log `executed_candidate_index`, candidate scores, candidate seeds, and selected/executed sequences for exact audit.

Do **not** assume SimVLA's 49D flow-denoising features transfer to a video model. The portable parts are deterministic multi-candidate sampling, the two-gate selector, temporal risk scoring pattern, and execution audit.
