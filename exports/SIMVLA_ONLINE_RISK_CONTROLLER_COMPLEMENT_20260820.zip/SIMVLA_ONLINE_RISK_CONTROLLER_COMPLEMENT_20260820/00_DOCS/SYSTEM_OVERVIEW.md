# System overview

At each decision query the controller observes current agent RGB, wrist RGB, instruction and 8D proprioception. It encodes the visual/language state **once**, then samples nine independent H10 action chunks from that same encoded state. Candidate 0 is the ordinary SimVLA proposal; candidates 1–8 are alternatives.

For every candidate the runtime builds candidate-specific uncertainty evidence and feeds the same frozen temporal risk monitor. The output is nine failure-risk scores in `[0,1]`. A two-threshold selector chooses either candidate 0 or the lowest-risk alternative. The chosen 10x7 environment-action chunk is executed open-loop for up to ten 30 Hz control ticks unless task success is reached earlier.

Risk input per candidate:
- history: `16 x 21`
- current candidate action chunk: `10 x 7` normalized
- static: `51` = 28 action statistics + 7 ACE + 8 proprio + selected TopK8 uncertainty features

TopK8 indices into the 49D uncertainty vector are `(6,21,25,27,23,2,26,24)`.
